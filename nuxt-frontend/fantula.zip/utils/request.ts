import axios from 'axios'
import type { AxiosRequestConfig } from 'axios'
import type { ApiResponse } from '@/types/api'

// 每次请求时动态获取config，避免SSR 500错误
function getAxiosInstance() {
  const config = useRuntimeConfig()
  const instance = axios.create({
    baseURL: config.public.apiBase,
    timeout: 10000,
    headers: {
      'Content-Type': 'application/json',
    }
  })

  // 请求拦截器
  instance.interceptors.request.use(
    (config) => {
      const token = useCookie('token')
      if (token.value) {
        // 使用sa-token格式，直接设置token header
        config.headers.token = token.value
      }
      if (config.method === 'get') {
        config.params = {
          ...config.params,
          _t: Date.now()
        }
      }
      return config
    },
    (error) => Promise.reject(error)
  )

  // 响应拦截器
  instance.interceptors.response.use(
    (response) => {
      // 适配后端Result格式到前端ApiResponse格式
      const result = response.data
      if (result && typeof result === 'object' && 'code' in result) {
        const adaptedResponse: ApiResponse<any> = {
          code: result.code,
          msg: result.msg,
          data: result.data,
          success: result.code === 0  // 后端code=0表示成功
        }
        response.data = adaptedResponse
      }
      return response
    },
    (error) => {
      if (error.response) {
        const { status, data } = error.response
        switch (status) {
          case 401:
            const token = useCookie('token')
            token.value = null
            navigateTo('/login')
            break
          case 403:
            break
          case 404:
            break
          case 500:
            break
        }
        // 处理后端错误格式
        if (data && typeof data === 'object' && 'msg' in data) {
          return Promise.reject(new Error(data.msg))
        }
        return Promise.reject(new Error(data?.msg || `HTTP ${status} 错误`))
      } else if (error.request) {
        return Promise.reject(new Error('网络连接失败，请检查网络设置'))
      } else {
        return Promise.reject(error)
      }
    }
  )
  return instance
}

export const http = {
  get<T = any>(url: string, params?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    return getAxiosInstance().get(url, { params, ...config }).then(res => res.data)
  },
  post<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    return getAxiosInstance().post(url, data, config).then(res => res.data)
  },
  put<T = any>(url: string, data?: any, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    return getAxiosInstance().put(url, data, config).then(res => res.data)
  },
  delete<T = any>(url: string, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    return getAxiosInstance().delete(url, config).then(res => res.data)
  },
  upload<T = any>(url: string, file: File, config?: AxiosRequestConfig): Promise<ApiResponse<T>> {
    const formData = new FormData()
    formData.append('file', file)
    return getAxiosInstance().post(url, formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      ...config
    }).then(res => res.data)
  },
  download(url: string, params?: any, filename?: string): Promise<void> {
    return getAxiosInstance().get(url, {
      params,
      responseType: 'blob'
    }).then((response) => {
      const blob = new Blob([response.data])
      const downloadUrl = window.URL.createObjectURL(blob)
      const link = document.createElement('a')
      link.href = downloadUrl
      link.download = filename || 'download'
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
      window.URL.revokeObjectURL(downloadUrl)
    })
  }
} 