<template>
  <div class="page-placeholder">关于我们页面建设中…</div>
</template>

<script setup lang="ts">
// 占位页面
</script>

<style scoped>
.page-placeholder {
  min-height: 60vh;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.5rem;
  color: #888;
}
</style> 