<template>
  <div class="goods-detail-page">
    <AppHeader />
    
    <!-- 加载状态 -->
    <div v-if="goodsPending" class="loading-container">
      <div class="loading-spinner">加载中...</div>
    </div>
    
    <!-- 错误状态 -->
    <div v-else-if="goodsError" class="error-container">
      <div class="error-message">
        <h3>加载失败</h3>
        <p>{{ goodsError.message || '商品信息加载失败，请稍后重试' }}</p>
        <button @click="() => refreshGoodsData()" class="retry-btn">重新加载</button>
      </div>
    </div>
    
    <!-- 正常内容 -->
    <div v-else class="goods-content">
      <!-- 返回按钮 -->
      <div class="back-btn-row">
        <button class="back-btn" @click="goBack">
          <span class="back-btn-icon">
            <svg width="32" height="32" viewBox="0 0 32 32" fill="none">
              <circle cx="16" cy="16" r="15" stroke="#2563EB" stroke-width="2" fill="#fff"/>
              <path d="M18.5 10L13 16L18.5 22" stroke="#2563EB" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </span>
          <span class="back-btn-text">返回</span>
        </button>
      </div>
      
      <!-- API错误提示（但继续显示内容） -->
      <div v-if="goodsError" class="api-error-notice">
        <div class="error-notice-content">
          <span class="error-icon">⚠️</span>
          <span class="error-text">API连接失败，显示默认商品信息</span>
          <button @click="() => refreshGoodsData()" class="retry-small-btn">重试</button>
        </div>
      </div>
      <!-- 主内容区 -->
      <div class="goods-detail-content">
        <div class="goods-main-section">
          <!-- 左侧：卖点区+主图+缩略图+服务保障区 -->
          <div class="goods-left-panel">
            <!-- 卖点区 -->
            <div class="features-bar">
              <div class="features-list">
                <div class="feature-item">
                  <span class="feature-icon">
                    <img src="/images/xiangqing1.png" alt="大团队开发" style="width:48px;height:48px;display:block;object-fit:contain;" />
                  </span>
                  <span class="feature-label">大团队开发</span>
                </div>
                <div class="feature-item">
                  <span class="feature-icon">
                    <img src="/images/xiangqing2.png" alt="人工客服服务" style="width:48px;height:48px;display:block;object-fit:contain;" />
                  </span>
                  <span class="feature-label">人工客服服务</span>
                </div>
                <div class="feature-item">
                  <span class="feature-icon">
                    <img src="/images/xiangqing3.png" alt="大平台更放心" style="width:48px;height:48px;display:block;object-fit:contain;" />
                  </span>
                  <span class="feature-label">大平台更放心</span>
                </div>
                <div class="feature-item">
                  <span class="feature-icon">
                    <img src="/images/xiangqing4.png" alt="全网矩阵" style="width:48px;height:48px;display:block;object-fit:contain;" />
                  </span>
                  <span class="feature-label">全网矩阵</span>
                </div>
              </div>
            </div>
            <!-- 主图外部白色大框 -->
            <div class="main-image-wrapper">
              <div class="main-image">
                <img :src="selectedImage || '/images/xiangqingzhutu1.png'" alt="商品主图" />
              </div>
              <div class="thumb-list">
                <div
                  v-for="(img, idx) in images"
                  :key="idx"
                  :class="['thumb', {active: selectedImage === img}]"
                  @click="img && (selectedImage = img)"
                >
                  <img v-if="img" :src="img" alt="预览图" class="thumb-img" />
                  <div v-else class="thumb-placeholder"></div>
                </div>
              </div>
            </div>
            <!-- 服务保障区 -->
            <div class="service-bar">
              <div class="service-list">
                <span class="service-item">官方采购・正品保障</span>
                <span class="service-item">全程质保・无忧售后</span>
                <span class="service-item">大平台更放心</span>
                <span class="service-item">全网矩阵・极速发货</span>
                <span class="service-item">7天无理由退换</span>
                <span class="service-item">假一赔十</span>
              </div>
            </div>
          </div>
          <!-- 右侧信息区 -->
          <div class="goods-info-panel">
            <div class="goods-title-row">
              <span class="goods-title">{{ goodsInfo.name }}</span>
              <span class="goods-sold">已售{{ goodsInfo.sales || '150354' }}</span>
            </div>
            <!-- 市场板块提示行 -->
            <div class="market-bar">买了车票没账号的？</div>
            <div class="goods-meta-row">
              <span class="goods-rating">4.9 <span class="meta-light">(1280条评价)</span></span>
              <span class="meta-light">全球解锁</span>
              <span class="meta-light">4K高清</span>
            </div>
            <div class="goods-price-row">
              <div class="row-label-bar">
                <span class="blue-bar"></span>
                <span class="goods-price-label">时长</span>
              </div>
              <div class="goods-duration-list">
                <button v-for="(d, idx) in durations1" :key="d" :class="['duration-btn', {active: selectedDurationIndex === idx}]" @click="selectedDurationIndex = idx">{{ d }}</button>
              </div>
            </div>
            <div class="goods-price-row">
              <div class="row-label-bar">
                <span class="blue-bar"></span>
                <span class="goods-price-label">时长</span>
              </div>
              <div class="goods-duration-list">
                <button v-for="(d, idx) in durations2" :key="d" :class="['duration-btn', {active: selectedDurationIndex === (idx + 4)}]" @click="selectedDurationIndex = idx + 4">{{ d }}</button>
              </div>
            </div>
            <div class="goods-final-price-row">
              <span class="goods-final-price">￥{{ goodsInfo.price }}</span>
            </div>
            <div class="goods-qty-row">
              <div class="row-label-bar">
                <span class="blue-bar"></span>
                <span class="goods-qty-label">购买数量</span>
              </div>
              <button class="qty-btn" @click="qty = Math.max(1, qty-1)">-</button>
              <span class="qty-value">{{ qty }}</span>
              <button class="qty-btn" @click="qty = qty+1">+</button>
            </div>
            <div class="goods-action-row">
              <button class="buy-btn" @click="buyNow">立即购买</button>
              <button class="cart-btn" @click="addToCart($event)">加入购物车</button>
              <button class="fav-btn" @click="toggleFavorite" :class="{active: isFavorited}">
                <span class="fav-icon">{{ isFavorited ? '♥' : '♡' }}</span>
                {{ isFavorited ? '已收藏' : '收藏' }}
              </button>
            </div>
            <div class="goods-disclaimer">
              本站所展示的所有徽标､商标及相关识别标志均归各⾃权利⼈所有，版权归原公司及其附属机构所有
            </div>
            <div class="goods-bottom-section">
              <div class="recommend-section">
                <div class="row-label-bar">
                  <span class="blue-bar"></span>
                  <span class="recommend-title">推荐搭配</span>
                </div>
                <div class="recommend-list">
                  <div class="recommend-item" v-for="item in recommends" :key="item.name">
                    <div class="recommend-thumb"></div>
                    <div class="recommend-name">{{ item.name }}</div>
                    <div class="recommend-price">{{ item.price }}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 超级大图区域 -->
      <div class="super-detail-image">
        <div class="super-detail-content">商品详情</div>
      </div>
      <AppFooter />
      <LoginRegisterModal :visible="modal.showLogin" @close="modal.closeLogin()" />
      <OrderPayModal
        v-if="showPayModal"
        :shopLogo="payGoods.shopLogo"
        :shopName="payGoods.shopName"
        :shopDesc="payGoods.shopDesc"
        :orderId="payGoods.orderId"
        :price="payGoods.price"
        :countdown="payCountdown"
        @close="handlePayClose"
        @timeout="handlePayTimeout"
        @paySuccess="handlePaySuccess"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import AppHeader from '@/components/AppHeader.vue'
import AppFooter from '@/components/AppFooter.vue'
import LoginRegisterModal from '@/components/LoginRegisterModal.vue'
import OrderPayModal from '@/components/OrderPayModal.vue'
import { useModalStore } from '@/stores/modal'
import { useRouter, useRoute } from 'vue-router'
import { ref, computed, onMounted, watch } from 'vue'
import { useCartStore } from '@/stores/cart'
import { useUserStore } from '@/stores/user'

const cartStore = useCartStore()
const modal = useModalStore()
const router = useRouter()
const route = useRoute()
const userStore = useUserStore()
const goBack = () => router.back()

// 获取商品ID
const goodsId = computed(() => Number(route.params.id) || 1)

// 🎨 前端UI设计阶段 - 静态商品数据（已注释，用于检查页面功能）
/*
const goodsInfo = ref({
  id: goodsId.value,
  name: 'Netflix 高级会员',
  image: '/images/xiangqingzhutu1.png',
  desc: '全球最大的流媒体平台，提供海量电影、电视剧和原创内容',
  region: '美国/香港/台湾',
  quality: '4K 超高清',
  devices: '4台同时在线',
  download: '是',
  prices: [
    { label: '月付', value: '¥35.00' },
    { label: '季付', value: '¥90.00' },
    { label: '年付', value: '¥320.00' }
  ],
  hot: true
})
*/

// ✅ 真实API调用（已启用）- 修复：使用更简单的useFetch方式
const { data: goodsData, error: goodsError, pending: goodsPending, refresh: refreshGoodsData } = useFetch<{success: boolean, data: any, msg: string}>(`/product/goods/${goodsId.value}`, {
  default: () => ({ success: false, data: null, msg: '' }),
  server: false,
  watch: [goodsId], // 监听goodsId变化，自动重新获取数据
  onRequest() {
    console.log('🔄 开始请求商品详情, 商品ID:', goodsId.value)
  },
  onResponse({ response }) {
    console.log('✅ 商品详情请求成功:', response._data)
  },
  onResponseError({ response }) {
    console.error('❌ 商品详情请求失败:', response._data)
  }
})

// 商品基本信息
const goodsInfo = computed(() => {
  if (goodsData.value && goodsData.value.success && goodsData.value.data) {
    const data = goodsData.value.data
    return {
      id: data.id,
      name: data.title || data.name,
      image: data.coverImage || data.image || '/images/xiangqingzhutu1.png',
      desc: data.description || '商品描述',
      region: '美国/香港/台湾', // 这些字段可能需要从后端获取
      quality: '4K 超高清',
      devices: '4台同时在线',
      download: '是',
      prices: [
        { label: '月付', value: `¥${data.price || 35}.00` },
        { label: '季付', value: `¥${(data.price || 35) * 3}.00` },
        { label: '年付', value: `¥${(data.price || 35) * 12}.00` }
      ],
      hot: data.status === 1,
      price: data.price || 35,
      sales: data.sales || 0 // 新增销售量
    }
  }
  
  // 如果API调用失败，返回默认数据
  return {
    id: goodsId.value,
    name: 'Netflix 高级会员',
    image: '/images/xiangqingzhutu1.png',
    desc: '全球最大的流媒体平台，提供海量电影、电视剧和原创内容',
    region: '美国/香港/台湾',
    quality: '4K 超高清',
    devices: '4台同时在线',
    download: '是',
    prices: [
      { label: '月付', value: '¥35.00' },
      { label: '季付', value: '¥90.00' },
      { label: '年付', value: '¥320.00' }
    ],
    hot: true,
    price: 35,
    sales: 0
  }
})

// 商品图片数组，动态获取并容错处理
const images = computed(() => {
  // 优先使用API返回的图片数组
  if (goodsData.value && goodsData.value.success && goodsData.value.data) {
    const data = goodsData.value.data
    // 假设后端返回字段为 images 或 imageList，类型为字符串数组
    let imgs = []
    if (Array.isArray(data.images)) {
      imgs = data.images.filter((img: string) => !!img)
    } else if (Array.isArray(data.imageList)) {
      imgs = data.imageList.filter((img: string) => !!img)
    } else if (data.coverImage || data.image) {
      imgs = [data.coverImage || data.image]
    }
    // 容错：无图片时给默认图
    if (!imgs.length) imgs = ['/images/xiangqingzhutu1.png']
    return imgs
  }
  // API失败时返回默认图片
  return ['/images/xiangqingzhutu1.png']
})

// selectedImage 响应 images 变化
const selectedImage = ref('')
watch(images, (val) => {
  selectedImage.value = val && val.length > 0 ? val[0] : '/images/xiangqingzhutu1.png'
}, { immediate: true })

const durations1 = ['月付', '季付', '年付立减￥40', '独享车位']
const durations2 = ['周付', '天付', '分钟付', '永久购买']
const selectedDurationIndex = ref(0)
const qty = ref(1)
const recommends = [
  { name: '苹果商店', price: '￥15元' },
  { name: 'Disney', price: '￥199元/年' },
  { name: 'Youtube', price: '￥240元/年' },
  { name: 'HBO Max', price: '￥189元/年' }
]
const showPayModal = ref(false)
const payCountdown = 900
const payGoods = ref<any>({})

function handlePayClose() { showPayModal.value = false }
function handlePayTimeout() { showPayModal.value = false /* 可加取消订单逻辑 */ }

// 支付成功处理
function handlePaySuccess(paymentInfo: any) {
  console.log('💰 商品详情页支付成功！', paymentInfo)
  
  // 添加新订单到订单列表
  const orderResult = userStore.addOrder({
    orderId: paymentInfo.orderId,
    title: goodsInfo.value.name,
    amount: paymentInfo.amount,
    payType: paymentInfo.payType,
    productImage: goodsInfo.value.image
  })
  
  if (orderResult.success) {
    console.log('✅ 订单已成功添加到我的订单列表')
    alert(`🎉 支付成功！\n商品：${goodsInfo.value.name}\n订单号：${paymentInfo.orderId}\n金额：¥${paymentInfo.amount}\n\n订单已添加到【我的订单】`)
  } else {
    alert(`🎉 支付成功！\n商品：${goodsInfo.value.name}\n订单号：${paymentInfo.orderId}\n金额：¥${paymentInfo.amount}`)
  }
  
  // 可以跳转到订单页面查看
  // router.push('/profile/orders')
}

function buyNow() {
  payGoods.value = {
    shopLogo: images.value && images.value.length > 0 ? images.value[0] : '/images/xiangqingzhutu1.png', // 安全访问
    shopName: 'Netflix',
    shopDesc: '',
    orderId: '模拟订单号',
    price: 29
  }
  showPayModal.value = true
}

const addToCart = (e?: Event) => {
  cartStore.addToCart({
    id: goodsId.value,
    name: goodsInfo.value.name,
    image: goodsInfo.value.image,
    price: 899, // 实际应为商品价格
    duration: '一个月', // 实际应为商品时长
    spec: '标准版' // 实际应为商品规格
  }, qty.value);
  // 抖动动画
  if (e && e.target) {
    const btn = e.target as HTMLElement;
    btn.classList.remove('shake');
    // 触发重绘
    void btn.offsetWidth;
    btn.classList.add('shake');
    btn.addEventListener('animationend', () => {
      btn.classList.remove('shake');
    }, { once: true });
  }
}

// 收藏相关功能
const isFavorited = computed(() => userStore.checkIsFavorite(goodsId.value))

const toggleFavorite = async () => {
  if (!userStore.isLoggedIn) {
    // 如果用户未登录，打开登录弹窗
    modal.showLogin = true
    return
  }

  if (isFavorited.value) {
    // 取消收藏
    const result = await userStore.removeFromFavorites(goodsId.value)
    if (result.success) {
      console.log('取消收藏成功')
    }
  } else {
    // 添加收藏
    // 注意：goodsInfo.value 需保证字段完整
    const result = await userStore.addToFavorites(goodsInfo.value)
    if (result.success) {
      console.log('添加收藏成功')
    } else {
      console.log(result.message)
    }
  }
}

// 组件挂载时初始化
onMounted(() => {
  // 这里可以根据路由参数获取商品详情
  // 实际项目中应该调用API获取商品信息
  console.log('商品详情页初始化 - 商品ID:', goodsId.value)
  console.log('路由参数:', route.params)
  console.log('当前路由:', route.path)
  
  // 检查API调用状态
  if (goodsError.value) {
    console.error('商品详情API调用失败:', goodsError.value)
  }
  
  if (goodsData.value) {
    console.log('商品详情API返回数据:', goodsData.value)
  }
})
</script>

<style scoped>
/* 加载和错误状态样式 */
.loading-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  background: #f8f9fa;
}

.loading-spinner {
  font-size: 18px;
  color: #666;
  display: flex;
  align-items: center;
  gap: 12px;
}

.loading-spinner::before {
  content: '';
  width: 24px;
  height: 24px;
  border: 3px solid #e0e0e0;
  border-top: 3px solid #235CDC;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 400px;
  background: #f8f9fa;
}

.error-message {
  text-align: center;
  padding: 40px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.error-message h3 {
  color: #dc2626;
  margin-bottom: 12px;
  font-size: 20px;
}

.error-message p {
  color: #666;
  margin-bottom: 20px;
  font-size: 16px;
}

.retry-btn {
  background: #235CDC;
  color: white;
  border: none;
  border-radius: 8px;
  padding: 12px 24px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.retry-btn:hover {
  background: #1d4ed8;
}

/* API错误提示样式 */
.api-error-notice {
  width: 1200px;
  margin: 0 auto 16px auto;
  background: #fff3cd;
  border: 1px solid #ffeaa7;
  border-radius: 8px;
  padding: 12px 16px;
}

.error-notice-content {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 14px;
  color: #856404;
}

.error-icon {
  font-size: 16px;
}

.error-text {
  flex: 1;
}

.retry-small-btn {
  background: #235CDC;
  color: white;
  border: none;
  border-radius: 4px;
  padding: 4px 12px;
  font-size: 12px;
  cursor: pointer;
  transition: background 0.2s;
}

.retry-small-btn:hover {
  background: #1d4ed8;
}

/* 原有样式 */
.goods-detail-page {
  min-height: 100vh;
  background: #fff;
  padding: 32px 0 0 0;
}
.back-btn-row {
  width: 1200px;
  margin: 24px auto 12px auto;
  display: flex;
  justify-content: flex-start;
}
.back-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  background: none;
  border: none;
  color: #2563EB;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  padding: 0 12px 0 0;
  transition: color 0.2s;
}
.back-btn-icon {
  display: flex;
  align-items: center;
  justify-content: center;
}
.back-btn-text {
  color: #2563EB;
  font-size: 18px;
  font-weight: 500;
}
.goods-detail-content {
  max-width: 1200px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  gap: 32px;
}
.goods-main-section {
  display: flex;
  gap: 32px;
  align-items: stretch;
  min-height: 600px;
}
.goods-left-panel {
  width: 600px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 18px;
  min-height: 100%;
  height: 100%;
}
.features-bar {
  width: 100%;
  background: linear-gradient(90deg, #EEF9FC 0%, #F5F3F2 50%, #FBEFE8 100%);
  border-radius: 20px;
  box-shadow: 0 4px 24px rgba(35,92,220,0.08);
  padding: 18px 0;
  display: flex;
  justify-content: center;
}
.features-list {
  display: flex;
  gap: 32px;
}
.feature-item {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 6px;
}
.feature-icon {
  margin-bottom: 2px;
}
.feature-label {
  font-size: 15px;
  color: #235CDC;
  font-weight: 500;
}
.main-image-wrapper {
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 4px 24px rgba(35,92,220,0.08);
  padding: 12px;
  margin-bottom: 12px;
  flex: 1 0 auto;
}
.main-image {
  width: 100%;
  height: 400px;
  background: #f8f8f8;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  box-shadow: none;
}
.main-image img {
  width: 100%;
  height: 100%;
  object-fit: contain;
}
.thumb-list {
  display: flex;
  gap: 16px;
  margin-top: 12px;
  justify-content: flex-start;
}
.thumb {
  width: 150px;
  height: 100px;
  border-radius: 8px;
  background: #f0f0f0;
  cursor: pointer;
  border: 2px solid transparent;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  transition: border 0.2s;
}
.thumb.active {
  border: 2px solid #235CDC;
}
.thumb-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}
.thumb-placeholder {
  width: 100%;
  height: 100%;
  background: #e5e7eb;
  border-radius: 8px;
}
.service-bar {
  width: 100%;
  background: #F9FAFB;
  border-radius: 14px;
  margin: 18px 0 0 0;
  padding: 18px 0 10px 0;
  box-shadow: 0 2px 8px rgba(35,92,220,0.04);
  display: flex;
  justify-content: center;
  margin-top: auto;
}
.service-list {
  display: flex;
  flex-wrap: wrap;
  gap: 24px 36px;
  font-size: 14px;
  color: #1F2937;
  font-family: 'Noto Sans SC', Noto Sans SC;
  font-weight: 400;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  width: 420px;
  justify-content: flex-start;
}
.service-item {
  width: 136px;
  height: 20px;
  padding: 0;
  background: none;
  color: #1F2937;
  border-radius: 0;
  display: flex;
  align-items: center;
  font-size: 14px;
  font-family: 'Noto Sans SC', Noto Sans SC;
  font-weight: 400;
  line-height: 20px;
  text-align: left;
  font-style: normal;
  text-transform: none;
}
.goods-info-panel {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 18px;
  padding-left: 16px;
  min-height: 100%;
  height: 100%;
  justify-content: flex-start;
}
.goods-title-row {
  display: flex;
  align-items: center;
  gap: 18px;
  font-size: 24px;
  font-weight: 700;
  color: #222;
  justify-content: space-between;
}
.goods-sold {
  font-size: 16px;
  color: #fff;
  background: #235CDC;
  border-radius: 16px;
  padding: 6px 28px;
  margin-left: 8px;
  font-weight: 600;
  min-width: 80px;
  text-align: center;
  box-sizing: border-box;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.goods-meta-row {
  display: flex;
  align-items: center;
  gap: 18px;
  font-size: 15px;
  color: #888;
}
.meta-light {
  color: #bbb;
  font-size: 14px;
}
.goods-price-row {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 8px;
  margin-top: 8px;
}
.goods-price-label {
  font-size: 15px;
  color: #888;
  min-width: 36px;
}
.goods-duration-list {
  display: flex;
  gap: 10px;
}
.duration-btn {
  width: 94px;
  height: 31px;
  font-size: 14px;
  color: #235CDC;
  background: #DBEAFE;
  border: none;
  border-radius: 20px;
  cursor: pointer;
  font-weight: 500;
  transition: background 0.2s, color 0.2s;
}
.duration-btn.active, .duration-btn:active {
  background: #2563EB;
  color: #fff;
}
.goods-final-price-row {
  font-size: 32px;
  color: #235CDC;
  font-weight: 700;
  margin: 8px 0;
}
.goods-qty-row {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 15px;
  margin-top: 8px;
}
.goods-qty-label {
  color: #888;
}
.qty-btn {
  width: 32px;
  height: 32px;
  border: none;
  background: #f2f7ff;
  color: #235CDC;
  font-size: 20px;
  border-radius: 50%;
  cursor: pointer;
  font-weight: 700;
  transition: background 0.2s, color 0.2s;
}
.qty-value {
  min-width: 28px;
  text-align: center;
  font-size: 18px;
}
.goods-action-row {
  display: flex;
  gap: 16px;
  margin: 18px 0 0 0;
}
.buy-btn {
  background: #235CDC;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 14px 0;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  width: 200px;
}
.cart-btn {
  background: #ffb400;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 14px 0;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
  width: 150px;
}
.fav-btn {
  background: #fff;
  color: #235CDC;
  border: 1.5px solid #235CDC;
  border-radius: 8px;
  padding: 14px 0;
  font-size: 18px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
  width: 90px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}
.fav-btn:hover {
  background: #235CDC;
  color: #fff;
}
.fav-btn.active {
  background: #235CDC;
  color: #fff;
}
.fav-icon {
  font-size: 18px;
}
.goods-disclaimer {
  font-family: 'Noto Sans SC', Noto Sans SC;
  font-weight: 400;
  font-size: 14px;
  color: #8B8B8B;
  line-height: 24px;
  text-align: left;
  font-style: normal;
  text-transform: none;
  margin-top: 10px;
  margin-bottom: 10px;
}
.goods-bottom-section {
  margin-top: auto;
}
.recommend-section {
  margin-top: 8px;
  display: flex;
  flex-direction: column;
}
.recommend-title {
  font-size: 18px;
  font-weight: 600;
  color: #222;
  margin-bottom: 8px;
  display: inline-block;
  margin-left: 8px;
}
.recommend-list {
  display: flex;
  gap: 18px;
  margin-top: 8px;
}
.recommend-item {
  width: 100px;
  background: #f8f8f8;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 12px 0;
  gap: 6px;
}
.recommend-thumb {
  width: 48px;
  height: 48px;
  background: #e0e0e0;
  border-radius: 8px;
  margin-bottom: 4px;
}
.recommend-name {
  font-size: 15px;
  color: #333;
  font-weight: 500;
}
.recommend-price {
  font-size: 13px;
  color: #888;
}
.market-bar {
  width: 100%;
  margin: 12px 0 0 0;
  background: linear-gradient(90deg, #D3F3FE 0%, #FDEDDD 49%, #FFE0D0 100%);
  border-radius: 15px;
  padding: 8px 18px;
  font-size: 15px;
  color: #235CDC;
  font-weight: 500;
  display: flex;
  align-items: center;
}
.blue-bar {
  width: 5px;
  height: 22px;
  background: #2563EB;
  border-radius: 3px;
  margin-right: 10px;
  display: inline-block;
  vertical-align: middle;
}
.row-label-bar {
  display: flex;
  align-items: center;
  margin-bottom: 8px;
}
.goods-price-label, .goods-qty-label, .recommend-title {
  font-size: 16px;
  color: #6B7280;
  font-weight: 600;
  font-family: 'Noto Sans SC', Noto Sans SC;
}
@media (max-width: 900px) {
  .goods-detail-header {
    flex-direction: column;
    gap: 16px;
    padding: 16px 8px;
  }
  .features-list {
    gap: 16px;
  }
  .goods-main-section {
    flex-direction: column;
    gap: 16px;
    padding: 16px;
  }
  .goods-gallery {
    width: 100%;
    flex-direction: row;
    gap: 8px;
  }
  .main-image {
    height: 180px;
  }
}
.super-detail-image {
  width: 1170px;
  height: 1199px;
  background: #D9D9D9;
  border-radius: 44px;
  margin: 40px auto 48px auto;
  display: flex;
  align-items: center;
  justify-content: center;
}
.super-detail-content {
  font-size: 56px;
  color: #222;
  font-weight: 500;
  letter-spacing: 8px;
}
@keyframes shake {
  0% { transform: translateX(0); }
  20% { transform: translateX(-6px); }
  40% { transform: translateX(6px); }
  60% { transform: translateX(-4px); }
  80% { transform: translateX(4px); }
  100% { transform: translateX(0); }
}
.cart-btn.shake {
  animation: shake 0.4s cubic-bezier(.36,.07,.19,.97) both;
}
</style> 