<template>
  <div class="community-page">
    <!-- 顶部导航 -->
    <AppHeader />
    <div class="page-content">


      <!-- 标签导航区域 -->
      <div class="category-tags">
        <button 
          v-for="tag in categoryTags" 
          :key="tag.key"
          :class="['tag-btn', { active: activeTag === tag.key && activeTag !== 'all' }]"
          :style="{ background: activeTag === tag.key ? tag.color : '#fff', color: activeTag === tag.key ? '#fff' : tag.color, border: `1.5px solid ${tag.color}` }"
          :title="activeTag === tag.key && activeTag !== 'all' ? '再次点击返回所有文章' : `查看${tag.label}分类文章`"
          @click="setActiveTag(tag.key)"
        >
          <span class="tag-icon">{{ tag.icon }}</span>
          {{ tag.label }}
          <span v-if="activeTag === tag.key && activeTag !== 'all'" class="reset-hint">×</span>
        </button>
      </div>

      <!-- 文章卡片区域 -->
      <div class="articles-grid">
        <div 
          v-for="article in filteredArticles" 
          :key="article.id"
          class="article-card"
          @click="viewArticle(article)"
        >
          <div class="article-image">
            <img :src="article.image" :alt="article.title" />
            </div>
          <div class="article-content">
            <h3 class="article-title">{{ article.title }}</h3>
            <p class="article-description">{{ article.description }}</p>
            <div class="article-meta">
              <span class="article-date">{{ article.date }}</span>
              <div class="article-author">
                <span class="author-avatar">{{ article.author.avatar }}</span>
                <span class="author-name">{{ article.author.name }}</span>
            </div>
            </div>
          </div>
        </div>
          </div>

      <!-- 发布文章按钮 -->
      <div class="publish-section">
        <button class="publish-btn" @click="openPublishModal">
          <span class="publish-icon">+</span>
          发布文章
        </button>
      </div>
    </div>
    <AppFooter />
    
    <!-- 登录注册弹窗 -->
    <LoginRegisterModal :visible="modal.showLogin" @close="modal.closeLogin()" />
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue'
import { useModalStore } from '@/stores/modal'

const modal = useModalStore()

// 当前激活的标签
const activeTag = ref('all')

// 分类标签数据
const categoryTags = [
  { key: 'equipment', label: '设备问题', icon: '🏠', color: '#FF7A7A' },
  { key: 'guide', label: '使用攻略', icon: '📝', color: '#4CAF50' },
  { key: 'troubleshoot', label: '故障解决', icon: '🔧', color: '#2196F3' },
  { key: 'screen', label: '手机投屏', icon: '📱', color: '#FF9800' },
  { key: 'security', label: '账号安全', icon: '🔒', color: '#4CAF50' }
]

// 文章数据
const articles = [
  {
    id: 1,
    title: '电视盒子看奈飞4K完整教程：解锁高清流媒体体验',
    description: '教你如何选择合适的电视盒子，安装奈飞App解码4K画质，解决播放卡顿问题...',
    image: '/images/help1.png',
    date: '2023年6月20日',
    category: 'guide',
    author: {
      avatar: '👨‍💻',
      name: '张科技'
    }
  },
  {
    id: 2,
    title: '迪士尼+家庭共享权限设置指南',
    description: '详解如何设置迪士尼+家庭组，管理子账户观看权限，解决地区限制问题...',
    image: '/images/help2.png',
    date: '2023-06-15',
    category: 'guide',
    author: {
      avatar: '👨‍👩‍👧‍👦',
      name: '家庭共享专家'
    }
  },
  {
    id: 3,
    title: 'Apple TV 2023终极设置指南',
    description: '从开箱到完美设置：网络优化、流媒体应用安装、遥控器技巧全攻略...',
    image: '/images/help3.png',
    date: '2023-06-10',
    category: 'equipment',
    author: {
      avatar: '🍎',
      name: '果粉工程师'
    }
  },
  {
    id: 4,
    title: '解决HBO Max卡顿缓冲的7个方法',
    description: '针对不同网络环境，提供有效的解决方案，告别视频加载和卡顿问题...',
    image: '/images/help4.png',
    date: '2023-06-05',
    category: 'troubleshoot',
    author: {
      avatar: '🔧',
      name: '网络优化师'
    }
  },
  {
    id: 5,
    title: '家庭多屏共享流媒体终极方案',
    description: '如何在不同设备间无缝切换观看，管理多个账号，节省订阅费用...',
    image: '/images/help5.png',
    date: '2023-05-28',
    category: 'screen',
    author: {
      avatar: '📺',
      name: '家庭影院顾问'
    }
  },
  {
    id: 6,
    title: '流媒体账号安全防护指南',
    description: '保护您的账号安全，防止盗号风险，设置安全的密码和双重验证...',
    image: '/images/help6.png',
    date: '2023-05-22',
    category: 'security',
    author: {
      avatar: '🔐',
      name: '安全技术专家'
    }
  }
]

// 根据标签筛选文章
const filteredArticles = computed(() => {
  if (activeTag.value === 'all') {
    return articles
  }
  return articles.filter(article => article.category === activeTag.value)
})

// 设置激活标签
const setActiveTag = (tagKey: string) => {
  // 如果点击的是当前已激活的标签，则返回显示所有文章
  if (activeTag.value === tagKey) {
    activeTag.value = 'all'
  } else {
    activeTag.value = tagKey
  }
}

// 获取分类标签名称
const getCategoryLabel = (tagKey: string) => {
  const tag = categoryTags.find(t => t.key === tagKey)
  return tag ? tag.label : tagKey
}

// 查看文章详情
const viewArticle = (article: any) => {
  // 如果是"电视盒子看奈飞4K完整教程"，跳转到详情页面
  if (article.id === 1) {
    navigateTo(`/article/${article.id}`)
  } else {
    // 其他文章暂时还没有详情页
    // TODO: 实现其他文章详情页
  }
}

// 打开发布文章弹窗
const openPublishModal = () => {
  // TODO: 实现发布文章功能
  // 这里可以打开发布文章的弹窗或跳转到发布页面
}

// SEO配置
useHead({
  title: '社区帮助 - 凡图拉',
  meta: [
    { name: 'description', content: '凡图拉社区帮助中心，为您提供全面的使用指南和客服支持。' }
  ]
})
</script>

<style scoped>
.community-page {
  min-height: 100vh;
  background: #f5f5f5;
  display: flex;
  flex-direction: column;
}

.page-content {
  flex: 1;
  width: 100%;
  max-width: 1400px;
  margin: 0 auto;
  padding: 60px 20px 40px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
}

/* 标签导航样式 */
.category-tags {
  display: flex;
  justify-content: center;
  gap: 16px;
  margin: 20px 0 40px;
  flex-wrap: wrap;
}

.tag-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 24px;
  border-radius: 50px;
  font-size: 15px;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  background: #fff;
  color: #666;
  border: 1.5px solid #eee;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.tag-btn.active {
  color: #fff !important;
  background: var(--tag-color, #2583f6) !important;
  border: 1.5px solid var(--tag-color, #2583f6) !important;
  box-shadow: 0 4px 16px rgba(0,0,0,0.12);
}

.tag-btn:hover {
  opacity: 0.92;
  transform: translateY(-2px);
}

.tag-icon {
  font-size: 16px;
}

.reset-hint {
  font-size: 18px;
  margin-left: 8px;
  opacity: 0.8;
  font-weight: bold;
}

/* 文章网格样式 */
.articles-grid {
  width: 100%;
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-bottom: 60px;
}

@media (max-width: 1200px) {
  .articles-grid {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 800px) {
  .articles-grid {
    grid-template-columns: 1fr;
  }
}

/* 文章卡片样式 */
.article-card {
  background: #fff;
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
  cursor: pointer;
  transition: all 0.3s ease;
  display: flex;
  flex-direction: column;
  height: 100%;
}

.article-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.12);
}

.article-image {
  width: 100%;
  height: 120px;
  overflow: hidden;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}

.article-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.article-content {
  padding: 20px;
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.article-title {
  font-size: 16px;
  font-weight: 600;
  color: #222;
  margin-bottom: 8px;
  line-height: 1.4;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.article-description {
  font-size: 13px;
  color: #666;
  line-height: 1.6;
  margin-bottom: 12px;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.article-meta {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.article-date {
  font-size: 12px;
  color: #999;
}

.article-author {
  display: flex;
  align-items: center;
  gap: 6px;
}

.author-avatar {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: #2583f6;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
}

.author-name {
  font-size: 12px;
  color: #2583f6;
  font-weight: 500;
}

/* 发布文章按钮样式 */
.publish-section {
  display: flex;
  justify-content: center;
}

.publish-btn {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 16px 32px;
  background: linear-gradient(135deg, #2583f6 0%, #1e70e6 100%);
  color: #fff;
  border: none;
  border-radius: 50px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  box-shadow: 0 4px 16px rgba(37, 131, 246, 0.3);
}

.publish-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(37, 131, 246, 0.4);
}

.publish-icon {
  font-size: 20px;
  font-weight: bold;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .page-content {
    padding: 16px 16px 40px;
  }
  
  .category-tags {
    gap: 8px;
  }
  
  .tag-btn {
    padding: 8px 16px;
    font-size: 12px;
  }
  
  .articles-grid {
    grid-template-columns: 1fr;
    gap: 16px;
  }
  
  .article-image {
    height: 100px;
  }
  
  .publish-btn {
    padding: 12px 24px;
    font-size: 14px;
  }
}
</style> 