<template>
  <div class="policy-page-bg">
    <AppHeader />
    <div class="policy-content">
      <div class="policy-header">
        <div class="policy-header-top">
          <img src="/images/logo.png" alt="logo" class="policy-header-logo" />
          <div class="policy-header-brand">凡图拉</div>
        </div>
        <div class="policy-header-title">用户协议</div>
        <div class="policy-header-en">Ventura Terms of Service</div>
        <div class="policy-header-desc">欢迎使用凡图拉平台服务，请您仔细阅读并充分理解本用户协议的各项条款</div>
      </div>
      <div class="policy-body">
        <div class="policy-left-panel">
          <div class="panel-header">
            <div class="panel-header-content">
              <div class="panel-title">中文版用户协议</div>
              <div class="panel-subtitle">Chinese Version of Terms of Service</div>
            </div>
          </div>
          <div class="panel-content">
            <div class="policy-overview-box">
              <div class="policy-overview-title">服务说明</div>
              <div class="policy-overview-desc">
                欢迎您使用凡图拉平台！在您注册成为用户、使用平台服务之前，请您务必仔细阅读、充分理解本协议全部内容，特别是以加粗方式标注的免责、限制责任、用户义务条款。若您不同意本协议内容，或无法准确理解相关条款，请停止使用凡图拉平台。
                <br><br>
                一旦您注册、登录或使用凡图拉平台，即视为您已阅读、理解并接受本协议的全部内容。
              </div>
            </div>

            <div class="policy-section-title">一、服务说明</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>1.1</strong> 凡图拉平台为用户提供数字商品的买、充值服务，包括但不限于会员订阅充值、礼品卡购买、虚拟商品转发等。平台以"礼品卡"形式对外展示商品信息，实际服务内容为中介性质的代充代付。
              </div>
              <div class="policy-section-item">
                <strong>1.2</strong> 本平台所提供服务并非目标服务商官方渠道，凡图拉为第三方平台，所提供服务基于用户自主下单行为完成。
              </div>
              <div class="policy-section-item">
                <strong>1.3</strong> 本平台不保证某一商品长期有效或目标服务商政策始终保持不变，如因政策调整导致商品无法使用、价格波动、服务中断等，平台将尽合理范围内协助处理，但不承担由此产生的法律责任。
              </div>
            </div>

            <div class="policy-section-title">二、用户注册与使用</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>2.1</strong> 用户可通过电子邮箱完成注册流程，注册即视为同意本协议内容。
              </div>
              <div class="policy-section-item">
                <strong>2.2</strong> 平台不会收集身份证、手机号、居住地址等敏感信息，亦不提供实名验证功能。
              </div>
              <div class="policy-section-item">
                <strong>2.3</strong> 用户账户仅限本人使用。如因用户自行泄露登录信息、误操作等造成损失，平台不承担责任。
              </div>
              <div class="policy-section-item">
                <strong>2.4</strong> 用户不得使用平台进行任何违法违规活动，包括但不限于：倒卖账号、洗钱、网络诈骗、传播违法内容等。一经发现，平台有权立即封禁账号并配合司法机关处理。
              </div>
            </div>

            <div class="policy-section-title">三、钱包与退款规则</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>3.1</strong> 如需退款经平台审核确认后，将退回至用户在平台内的钱包余额中。
              </div>
              <div class="policy-section-item">
                <strong>3.2</strong> 平台钱包余额可用于再次购买平台商品，但不可提现或转账至其他人账户。
              </div>
              <div class="policy-section-item">
                <strong>3.3</strong> 平台有权依据商品类型、发货状态决定是否支持退款或部分退款。
              </div>
            </div>

            <div class="policy-section-title">四、售后服务与责任范围</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>4.1</strong> 凡图拉提供国内微信客服，国际将支持 Telegram 或 WhatsApp。
              </div>
              <div class="policy-section-item">
                <strong>4.2</strong> 平台协助处理充值失败等问题，但不对目标平台自身政策变动等承担责任。
              </div>
              <div class="policy-section-item">
                <strong>4.3</strong> 虚拟商品一经发货即无法退货，若用户提供错误信息导致问题，平台不承担责任。
              </div>
            </div>

            <div class="policy-section-title">五、知识产权与免责声明</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>5.1</strong> 商标、品牌标识归属原品牌方所有，平台仅作功能识别之用。
              </div>
              <div class="policy-section-item">
                <strong>5.2</strong> 平台展示内容不代表授权或官方合作，若权利方认为展示不当，平台将配合处理。
              </div>
              <div class="policy-section-item">
                <strong>5.3</strong> 用户下单即视为同意平台为第三方中介，并承担因服务变动带来的使用风险。
              </div>
            </div>

            <div class="policy-section-title">六、法律适用与争议解决</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>6.1</strong> 本协议适用中华人民共和国法律。
              </div>
              <div class="policy-section-item">
                <strong>6.2</strong> 如发生争议，双方应协商解决，协商不成的，由平台所在地人民法院管辖。
              </div>
              <div class="policy-section-item">
                <strong>6.3</strong> 凡图拉保留本协议最终解释权及修改权。
              </div>
            </div>

            <div class="policy-section-title">七、附议</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>7.1</strong> 协议自注册日起生效，平台将通过公告形式更新协议内容。
              </div>
            </div>
          </div>
        </div>
        <div class="policy-right-panel">
          <div class="panel-header">
            <div class="panel-header-content">
              <div class="panel-title">English Version</div>
              <div class="panel-subtitle">Ventura Terms of Service</div>
            </div>
          </div>
          <div class="panel-content">
            <div class="policy-overview-box">
              <div class="policy-overview-title">Terms of Service</div>
              <div class="policy-overview-desc">
                Welcome to Ventura Platform! Before registering as a user or using platform services, please carefully read and fully understand all contents of this agreement, especially the disclaimer, limitation of liability, and user obligation clauses marked in bold. If you do not agree with the contents of this agreement or cannot accurately understand relevant clauses, please stop using Ventura Platform.
                <br><br>
                Once you register, log in or use Ventura Platform, you are deemed to have read, understood and accepted all contents of this agreement.
              </div>
            </div>

            <div class="policy-section-title">1. Service Description</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>1.1</strong> Ventura Platform provides users with digital product purchasing and top-up services, including but not limited to membership subscription top-ups, gift card purchases, virtual product forwarding, etc. The platform displays product information in the form of "gift cards", and the actual service content is intermediary agency payment.
              </div>
              <div class="policy-section-item">
                <strong>1.2</strong> The services provided by this platform are not official channels of target service providers. Ventura is a third-party platform, and the services provided are completed based on users' autonomous ordering behavior.
              </div>
              <div class="policy-section-item">
                <strong>1.3</strong> This platform does not guarantee that a certain product will be valid for a long time or that the target service provider's policies will remain unchanged. If products cannot be used, prices fluctuate, services are interrupted, etc. due to policy adjustments, the platform will assist in handling within a reasonable scope, but will not bear legal responsibility arising therefrom.
              </div>
            </div>

            <div class="policy-section-title">2. User Registration and Usage</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>2.1</strong> Users can complete the registration process through email, and registration is deemed as agreement to the contents of this agreement.
              </div>
              <div class="policy-section-item">
                <strong>2.2</strong> The platform will not collect sensitive information such as ID cards, mobile phone numbers, residential addresses, nor provide real-name verification functions.
              </div>
              <div class="policy-section-item">
                <strong>2.3</strong> User accounts are limited to personal use only. If losses are caused by users' own disclosure of login information, misoperations, etc., the platform will not bear responsibility.
              </div>
              <div class="policy-section-item">
                <strong>2.4</strong> Users shall not use the platform for any illegal activities, including but not limited to: reselling accounts, money laundering, online fraud, spreading illegal content, etc. Once discovered, the platform has the right to immediately ban the account and cooperate with judicial authorities.
              </div>
            </div>

            <div class="policy-section-title">3. Wallet and Refund Rules</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>3.1</strong> If a refund is requested and approved by the platform, the amount will be returned to the user's wallet balance on the platform.
              </div>
              <div class="policy-section-item">
                <strong>3.2</strong> The platform wallet balance can be used to purchase platform goods again, but cannot be withdrawn or transferred to other account.
              </div>
              <div class="policy-section-item">
                <strong>3.3</strong> The platform has the right to determine whether to support a refund or partial refund based on the type of goods and delivery status.
              </div>
            </div>

            <div class="policy-section-title">4. After-Sales Service and Responsibility Scope</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>4.1</strong> Ventura provides domestic WeChat customer service, and international support will be provided through Telegram or WhatsApp.
              </div>
              <div class="policy-section-item">
                <strong>4.2</strong> The platform assists in handling issues such as failed top-up, but does not bear responsibility for changes in the target platform's policy itself.
              </div>
              <div class="policy-section-item">
                <strong>4.3</strong> Virtual goods cannot be returned once shipped. If the user provides incorrect information causing issues, the platform will not bear responsibility.
              </div>
            </div>

            <div class="policy-section-title">5. Intellectual Property and Disclaimer</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>5.1</strong> The trademarks and brand identifiers belong to the original brand owners, and the platform is used for functional recognition only.
              </div>
              <div class="policy-section-item">
                <strong>5.2</strong> The platform content does not represent authorization or official cooperation. If the rights holder believes that the display is inappropriate, the platform will cooperate with processing.
              </div>
              <div class="policy-section-item">
                <strong>5.3</strong> Users' placing orders is deemed as agreeing to the platform as a third-party intermediary and accepting the usage risks brought by service changes.
              </div>
            </div>

            <div class="policy-section-title">6. Law Applicable and Dispute Resolution</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>6.1</strong> This agreement applies to the laws of the People's Republic of China.
              </div>
              <div class="policy-section-item">
                <strong>6.2</strong> If disputes arise, both parties should resolve them through consultation. If consultation fails, the court where the platform is located shall have jurisdiction.
              </div>
              <div class="policy-section-item">
                <strong>6.3</strong> Ventura reserves the final interpretation and modification rights of this agreement.
              </div>
            </div>

            <div class="policy-section-title">7. Final Provisions</div>
            <div class="policy-section-line"></div>
            
            <div class="policy-highlight-box">
              <div class="policy-section-item">
                <strong>7.1</strong> This agreement takes effect from the date of registration, and the platform will update the agreement content through announcements.
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="policy-bottom-section">
        <div class="policy-legal-notice">
          <div class="legal-notice-title">法律声明与附则</div>
          
          <div class="legal-content-box">
            <div class="legal-notice-section">
              <div class="legal-section-title">五、知识产权与免责声明</div>
              <div class="legal-section-item">5.1 商标、品牌标识归属原品牌方所有，平台仅作功能识别之用。</div>
              <div class="legal-section-item">5.2 平台展示内容不代表授权或官方合作，若权利方认为展示不当，平台将配合处理。</div>
              <div class="legal-section-item">5.3 用户下单即视为同意平台为第三方中介，并承担因服务变动带来的使用风险。</div>
            </div>

            <div class="legal-notice-section">
              <div class="legal-section-title">六、法律适用与争议解决</div>
              <div class="legal-section-item">6.1 本协议适用中华人民共和国法律。</div>
              <div class="legal-section-item">6.2 如发生争议，双方应协商解决，协商不成的，由平台所在地人民法院管辖。</div>
              <div class="legal-section-item">6.3 凡图拉保留本协议最终解释权及修改权。</div>
            </div>

            <div class="legal-notice-section">
              <div class="legal-section-title">七、附则</div>
              <div class="legal-section-item">7.1 协议自注册日起生效，平台将通过公告形式更新协议内容。</div>
            </div>
          </div>

          <div class="legal-disclaimer">
            In case of any discrepancy between the Chinese and English versions, the Chinese version shall prevail.
          </div>
        </div>
      </div>
    </div>
    <AppFooter />

    <!-- 登录注册弹窗 -->
    <LoginRegisterModal :visible="modal.showLogin" @close="modal.closeLogin()" />
  </div>
</template>

<script setup lang="ts">
import AppHeader from '@/components/AppHeader.vue'
import AppFooter from '@/components/AppFooter.vue'
import LoginRegisterModal from '@/components/LoginRegisterModal.vue'
import { useModalStore } from '@/stores/modal'

const modal = useModalStore()
</script>

<style scoped>
.policy-page-bg {
  min-height: 100vh;
  margin: 0 auto;
  background: #f8faff;
  display: flex;
  flex-direction: column;
}

.policy-content {
  flex: 1;
  max-width: 1400px;
  width: 90vw;
  margin: 60px auto 60px auto;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.04);
  padding: 40px 30px;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.policy-header {
  width: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 32px;
  margin-bottom: 32px;
}

.policy-header-top {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 16px;
}

.policy-header-logo {
  width: 60px;
  height: 60px;
  border-radius: 50%;
  margin-right: 12px;
}

.policy-header-brand {
  font-size: 28px;
  font-weight: bold;
  color: #2583f6;
  margin: 0;
  letter-spacing: 1px;
}

.policy-header-title {
  font-size: 24px;
  font-weight: bold;
  color: #222;
  margin-bottom: 6px;
  text-align: center;
}

.policy-header-en {
  font-size: 16px;
  color: #888;
  margin-bottom: 8px;
  text-align: center;
}

.policy-header-desc {
  font-size: 14px;
  color: #888;
  margin-bottom: 0;
  line-height: 1.4;
  text-align: center;
}

.policy-body {
  display: flex;
  justify-content: center;
  align-items: flex-start;
  gap: 32px;
  width: 100%;
  margin: 0 auto;
  flex: 1;
  overflow: hidden;
  max-width: 1300px;
}

.policy-left-panel,
.policy-right-panel {
  width: 42vw;
  max-width: 600px;
  min-width: 400px;
  height: calc(100vh - 300px);
  min-height: 600px;
  background: #FFFFFF;
  box-shadow: 0px 10px 40px 0px rgba(0,0,0,0.08);
  border-radius: 20px 20px 20px 20px;
  overflow: hidden;
  flex-shrink: 0;
  border: 1px solid #e5e5e5;
}

.panel-header {
  width: 100%;
  height: 80px;
  background: linear-gradient(135deg, #1890FF 0%, #096DD9 100%);
  border-radius: 20px 20px 0px 0px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.panel-header-content {
  text-align: center;
  color: white;
}

.panel-title {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 4px;
}

.panel-subtitle {
  font-size: 14px;
  opacity: 0.9;
}

.panel-content {
  padding: 16px;
  height: calc(100% - 80px);
  overflow-y: auto;
}

.policy-col {
  flex: 1;
  max-width: calc(1640px - 585px - 32px);
  background: #fff;
  border-radius: 12px;
  padding: 32px;
  font-size: 16px;
  color: #222;
  line-height: 1.8;
}

.policy-col h2 {
  color: #2583f6;
  font-weight: bold;
  font-size: 22px;
  border-left: 4px solid #2583f6;
  padding-left: 8px;
  margin-bottom: 16px;
}

.policy-overview-box {
  width: 100%;
  height: auto;
  min-height: 120px;
  background: #F8FAFF;
  border-radius: 8px;
  border: 1px solid #EAEAEA;
  box-sizing: border-box;
  margin-bottom: 24px;
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 20px;
}

.policy-overview-title {
  color: #2583f6;
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 12px;
}

.policy-overview-desc {
  color: #444;
  font-size: 14px;
  line-height: 1.8;
}

.policy-section-title {
  color: #2583f6;
  font-weight: bold;
  font-size: 18px;
  border-left: 4px solid #2583f6;
  padding-left: 8px;
  margin-top: 24px;
  margin-bottom: 0;
  line-height: 1.7;
}

.policy-section-line {
  width: 100%;
  height: 2px;
  background: #e3f0ff;
  margin: 8px 0 16px 0;
  border-radius: 2px;
}

.policy-highlight-box {
  width: 100%;
  height: auto;
  min-height: 60px;
  background: #E6F7FF;
  border-radius: 0px 8px 8px 0px;
  border-left: 4px solid #1890FF;
  border-top: none;
  border-right: none;
  border-bottom: none;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  margin: 16px 0 24px 0;
  color: #222;
  font-size: 14px;
  font-weight: normal;
  line-height: 1.8;
  padding: 16px 20px;
}

.policy-section-item {
  margin-bottom: 12px;
  color: #222;
  font-size: 14px;
  line-height: 1.8;
}

.policy-section-item:last-child {
  margin-bottom: 0;
}

.policy-section-item strong {
  font-weight: bold;
  color: #222;
}

.policy-bottom-section {
  width: 100%;
  display: flex;
  justify-content: center;
  padding: 32px 0;
  margin-top: 32px;
}

.policy-legal-notice {
  width: 90%;
  max-width: 1200px;
  background: #E6F7FF;
  border-radius: 16px;
  padding: 32px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.06);
}

.legal-notice-title {
  font-size: 24px;
  font-weight: bold;
  color: #2583f6;
  margin-bottom: 32px;
  text-align: center;
}

.legal-content-box {
  background: #fff;
  border-radius: 12px;
  padding: 32px;
  margin-bottom: 24px;
  text-align: center;
  box-shadow: 0 2px 8px rgba(0,0,0,0.04);
}

.legal-notice-section {
  margin-bottom: 32px;
  text-align: center;
}

.legal-section-title {
  font-size: 18px;
  font-weight: bold;
  color: #222;
  margin-bottom: 16px;
  text-align: center;
}

.legal-section-item {
  font-size: 14px;
  color: #444;
  line-height: 1.8;
  margin-bottom: 8px;
  text-align: center;
}

.legal-disclaimer {
  font-size: 14px;
  color: #666;
  text-align: center;
  margin-top: 24px;
  padding-top: 24px;
  border-top: 1px solid rgba(37, 131, 246, 0.2);
  font-style: italic;
}
</style> 