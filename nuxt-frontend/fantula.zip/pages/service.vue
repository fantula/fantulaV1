<template>
  <div></div>
</template>

<script setup lang="ts">
// SEO配置
useHead({
  title: '客服中心 - 凡图拉',
  meta: [
    { name: 'description', content: '凡图拉客服中心，7×24小时全天候服务，为您提供专业的技术支持和问题解答。' }
  ]
})
</script> 