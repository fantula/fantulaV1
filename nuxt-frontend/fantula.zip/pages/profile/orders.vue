<template>
        <div class="orders-section">
          <div class="section-header">
            <h2 class="section-title">我的订单</h2>
          </div>
          <div class="order-tabs">
            <div 
              v-for="tab in orderTabs" 
              :key="tab"
              :class="['tab-item', { active: activeTab === tab }]"
              @click="activeTab = tab"
            >
              {{ tab }}
            </div>
          </div>
          
          <!-- 空状态 -->
          <div v-if="filteredOrders.length === 0" class="empty-state">
            <div class="empty-icon">📦</div>
            <div class="empty-text">暂无相关订单</div>
            <div class="empty-desc">快去下单购买您喜欢的商品吧~</div>
            <button class="go-shopping-btn" @click="goShopping">去购物</button>
          </div>
          
          <!-- 订单列表 -->
          <div v-else class="order-list">
            <div class="order-item" v-for="order in filteredOrders" :key="order.id">
              <div class="order-image">
                <div class="placeholder-img">
                  <img v-if="order.productImage" :src="order.productImage" alt="商品图片" class="product-img" />
                </div>
              </div>
              <div class="order-info">
          <div class="order-title">{{ order.title }}</div>
                <div class="order-details">
            <span class="order-number">订单号：{{ order.id }}</span>
            <span class="order-amount">金额：{{ order.amount }}</span>
            <span class="order-time">下单时间：{{ order.time }}</span>
                  <span v-if="order.payType" class="order-paytype">支付方式：{{ getPayTypeText(order.payType) }}</span>
                </div>
              </div>
              <div class="order-actions">
          <div class="order-status" :class="order.statusClass">{{ order.statusText }}</div>
          <button v-if="order.status === 'pending'" class="btn-pay">支付</button>
          <button v-if="order.status === 'pending'" class="btn-cancel">取消</button>
          <button v-if="order.status === 'shipped'" class="btn-detail" @click="openDetailModal(order)">查看详情</button>
          <button v-if="order.status === 'expired' || order.status === 'completed'" class="btn-delete">删除</button>
          <button v-if="order.status === 'expired' || order.status === 'completed'" class="btn-reorder">再来一单</button>
        </div>
      </div>
    </div>
  </div>
  
  <div v-if="showDetailModal" class="order-detail-modal-mask" @click.self="closeDetailModal">
    <div class="order-detail-modal">
      <div class="modal-header">
        <div class="modal-title">订单详情</div>
        <div class="modal-subtitle">请填写内容</div>
        <button class="modal-close" @click="closeDetailModal">×</button>
      </div>
      <div class="modal-body">
        <div class="modal-form-row" v-for="(label, key) in {channel:'频道名称',account:'登陆账号',password:'登录密码',backup:'备用码',remark:'备注'}" :key="key">
          <div class="modal-label">{{ label }}</div>
          <input class="modal-input" v-model="detailForm[key]" :placeholder="'请输入兑换码'" />
        </div>
        <button class="modal-submit" @click="submitDetail">提交</button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue'
import { orderApi } from '@/api/order'
import { useRouter } from 'vue-router'

const router = useRouter()

const orderTabs = ['全部', '待支付', '待发货', '已发货', '已完成', '已过期']
const activeTab = ref('全部')
const orderList = ref<any[]>([])

const fetchOrders = async () => {
  const res = await orderApi.getOrderList({ page: 1, limit: 100 })
  if (res && res.data && res.data.list) orderList.value = res.data.list
}
onMounted(fetchOrders)

const filteredOrders = computed(() => {
  if (activeTab.value === '全部') return orderList.value
  // 这里需根据后端orderStatus与tab的映射关系调整
  const statusMap: Record<string, number[]> = {
    '待支付': [0],
    '待发货': [1],
    '已发货': [2],
    '已完成': [4],
    '已过期': [3, 5]
  }
  return orderList.value.filter(order => statusMap[activeTab.value]?.includes(order.orderStatus))
})

const getPayTypeText = (payType: string) => {
  const typeMap: Record<string, string> = {
    'alipay': '支付宝',
    'balance': '余额支付',
    'other': '其他支付'
  }
  return typeMap[payType] || payType
}

const showDetailModal = ref(false)
const currentOrder = ref<any>(null)
const openDetailModal = (order: any) => {
  currentOrder.value = order
  showDetailModal.value = true
}
const closeDetailModal = () => { showDetailModal.value = false }
const detailForm = ref({ channel: '', account: '', password: '', backup: '', remark: '' })
const submitDetail = () => { closeDetailModal() }
const goShopping = () => { router.push('/') }
</script>
<style scoped>
.orders-section {
  padding: 0;
  height: 100%;
}
.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
  padding-bottom: 15px;
  border-bottom: 1px solid #f0f0f0;
}
.section-title {
  font-size: 20px;
  font-weight: 600;
  color: #333;
  margin: 0;
}
.order-tabs {
  display: flex;
  gap: 20px;
  margin-bottom: 30px;
  border-bottom: 1px solid #e9ecef;
  padding-bottom: 15px;
}
.tab-item {
  padding: 8px 0;
  color: #999;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 16px;
  position: relative;
}
.tab-item.active {
  color: #4A90E2;
  font-weight: 500;
}
.tab-item.active::after {
  content: '';
  position: absolute;
  bottom: -16px;
  left: 0;
  width: 100%;
  height: 3px;
  background: #4A90E2;
  border-radius: 2px;
}
.order-list {
  display: flex;
  flex-direction: column;
  gap: 28px;
}
.order-item {
  display: flex;
  align-items: center;
  padding: 24px 32px;
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 4px 18px rgba(24,144,255,0.08);
  border: none;
  transition: box-shadow 0.2s;
}
.order-item:hover {
  box-shadow: 0 8px 32px rgba(24,144,255,0.15);
}
.order-image {
  width: 80px;
  height: 60px;
  margin-right: 24px;
  flex-shrink: 0;
}
.placeholder-img {
  width: 100%;
  height: 100%;
  background: #d1d3d4;
  border-radius: 8px;
  border: 2px dashed #999;
  display: flex;
  align-items: center;
  justify-content: center;
}
.product-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}
.order-info {
  flex: 1;
  text-align: left;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.order-title {
  font-size: 16px;
  color: #333;
  font-weight: 500;
  margin-bottom: 4px;
}
.order-details {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.order-number, .order-amount, .order-time {
  font-size: 14px;
  color: #666;
}
.order-paytype {
  font-size: 14px;
  color: #666;
}
.order-actions {
  display: flex;
  flex-direction: row;
  align-items: center;
  gap: 10px;
  min-width: 300px;
  justify-content: flex-end;
}
.order-status {
  padding: 6px 16px;
  border-radius: 20px;
  font-size: 14px;
  font-weight: 500;
  white-space: nowrap;
  margin-right: 8px;
}
.order-status.pending {
  background: #fff3cd;
  color: #faad14;
  border: 1px solid #ffeaa7;
}
.order-status.shipped {
  background: #e6f7ff;
  color: #1890FF;
  border: 1px solid #91d5ff;
}
.order-status.completed {
  background: #eaffea;
  color: #52c41a;
  border: 1px solid #b7eb8f;
}
.order-status.expired {
  background: #f0f0f0;
  color: #999;
  border: 1px solid #d9d9d9;
}
.btn-pay {
  background: #4A90E2;
  color: white;
  border: none;
  border-radius: 20px;
  padding: 8px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}
.btn-pay:hover {
  background: #357ABD;
}
.btn-cancel, .btn-detail, .btn-delete, .btn-reorder {
  background: #fff;
  color: #4A90E2;
  border: 1px solid #4A90E2;
  border-radius: 20px;
  padding: 8px 20px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
}
.btn-cancel:hover, .btn-detail:hover, .btn-delete:hover, .btn-reorder:hover {
  background: #4A90E2;
  color: #fff;
}
/* 空状态样式 */
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 80px 20px;
  text-align: center;
}

.empty-icon {
  font-size: 80px;
  margin-bottom: 20px;
  opacity: 0.6;
}

.empty-text {
  font-size: 18px;
  color: #333;
  font-weight: 500;
  margin-bottom: 8px;
}

.empty-desc {
  font-size: 14px;
  color: #666;
  margin-bottom: 30px;
}

.go-shopping-btn {
  background: #4A90E2;
  color: white;
  border: none;
  border-radius: 20px;
  padding: 12px 30px;
  font-size: 16px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.go-shopping-btn:hover {
  background: #357ABD;
}

/* 商品图片样式 */
.product-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 6px;
}

/* 支付方式样式 */
.order-paytype {
  font-size: 14px;
  color: #666;
}

.order-detail-modal-mask {
  position: fixed;
  z-index: 3000;
  left: 0; top: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.10);
  display: flex;
  align-items: center;
  justify-content: center;
}
.order-detail-modal {
  width: 420px;
  background: #fff;
  border-radius: 32px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(24,144,255,0.13);
  display: flex;
  flex-direction: column;
}
.modal-header {
  background: linear-gradient(120deg, #2196F3 0%, #1976D2 100%);
  border-radius: 32px 32px 0 0;
  padding: 32px 0 18px 0;
  text-align: center;
  position: relative;
}
.modal-title {
  font-size: 28px;
  font-weight: 900;
  color: #fff;
  margin-bottom: 8px;
}
.modal-subtitle {
  font-size: 16px;
  color: #e3f2fd;
  margin-bottom: 0;
}
.modal-close {
  position: absolute;
  right: 24px;
  top: 24px;
  background: none;
  border: none;
  color: #fff;
  font-size: 32px;
  cursor: pointer;
  line-height: 1;
}
.modal-body {
  padding: 32px 28px 32px 28px;
  display: flex;
  flex-direction: column;
  gap: 22px;
}
.modal-form-row {
  display: flex;
  align-items: center;
  margin-bottom: 0;
}
.modal-label {
  width: 90px;
  font-size: 18px;
  color: #222;
  font-weight: 700;
  text-align: left;
}
.modal-input {
  flex: 1;
  height: 44px;
  border-radius: 22px;
  border: 1.5px solid #e3eaf2;
  background: #fafbfc;
  font-size: 16px;
  padding: 0 18px;
  margin-left: 8px;
  outline: none;
  transition: border 0.2s;
}
.modal-input:focus {
  border: 1.5px solid #2196F3;
}
.modal-submit {
  width: 100%;
  background: linear-gradient(120deg, #2196F3 0%, #1976D2 100%);
  color: #fff;
  border: none;
  border-radius: 22px;
  font-size: 20px;
  font-weight: 900;
  padding: 14px 0;
  cursor: pointer;
  margin-top: 18px;
  box-shadow: 0 2px 8px rgba(33,150,243,0.10);
  transition: background 0.2s;
}
.modal-submit:hover {
  background: linear-gradient(120deg, #1976D2 0%, #2196F3 100%);
}
</style> 