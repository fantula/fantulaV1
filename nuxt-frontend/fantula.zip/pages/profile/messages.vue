<template>
  <div class="messages-section">
    <div class="section-header">
      <h2 class="section-title">我的消息</h2>
    </div>
    <div class="placeholder-content">
      <h2>暂无消息</h2>
      <p>消息功能正在开发中...</p>
    </div>
  </div>
</template>
<script setup lang="ts">
import { useUserStore } from '@/stores/user'
const userStore = useUserStore()
</script>
<style scoped>
.messages-section { padding: 0; height: 100%; }
.section-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding-bottom: 15px; border-bottom: 1px solid #f0f0f0; }
.section-title { font-size: 20px; font-weight: 600; color: #333; margin: 0; }
.placeholder-content { text-align: center; padding: 60px 20px; color: #999; }
.placeholder-content h2 { font-size: 24px; margin-bottom: 10px; }
.placeholder-content p { font-size: 16px; }
</style> 