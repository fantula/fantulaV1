<template>
  <div class="login-page">
    <!-- 顶部导航 -->
    <AppHeader />
    
    <!-- 登录表单区域 -->
    <div class="login-container">
      <div class="login-box">
        <h1 class="login-title">用户登录</h1>
        <form @submit.prevent="handleLogin" class="login-form">
          <div class="form-group">
            <label>邮箱/手机号:</label>
            <input 
              v-model="loginForm.email" 
              type="text" 
              placeholder="请输入邮箱或手机号"
              required 
            />
          </div>
          <div class="form-group">
            <label>密码:</label>
            <input 
              v-model="loginForm.password" 
              type="password" 
              placeholder="请输入密码"
              required 
            />
          </div>
          <button type="submit" class="login-btn" :disabled="loading">
            {{ loading ? '登录中...' : '登录' }}
          </button>
        </form>
        
        <div class="test-account">
          <p><strong>测试账号：</strong></p>
          <p>手机号: 13612345678</p>
          <p>密码: admin</p>
        </div>
      </div>
    </div>
    
    <!-- 页脚 -->
    <AppFooter />
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useUserStore } from '@/stores/user'

// SEO配置
useHead({
  title: '用户登录 - 凡图拉'
})

const userStore = useUserStore()

const loading = ref(false)
const loginForm = ref({
  email: '',
  password: ''
})

const handleLogin = async () => {
  loading.value = true
  
  // 🎨 前端UI设计阶段 - 模拟登录（已注释，用于检查页面功能）
  /*
  setTimeout(() => {
    const mockUser = {
      id: 1,
      username: loginForm.value.email?.split('@')[0] || 'dev_user',
      email: loginForm.value.email,
      avatar: '/images/default-avatar.png'
    }
    userStore.setUser(mockUser, 'dev-token-' + Date.now())
    alert('登录成功！（开发模式）')
    window.location.reload()
    loading.value = false
  }, 1000)
  */
  
  // ✅ 真实API调用（已启用）
  try {
    const res = await $fetch<{code: number, data: any, msg: string}>('/product/common/mail/login', {
      method: 'POST',
      body: {
        email: loginForm.value.email,
        password: loginForm.value.password
      }
    })
    if (res.code === 0 && res.data) {
      userStore.setUser(res.data, res.data.tokenValue)
      alert('登录成功！')
      window.location.reload()
    } else {
      alert(res.msg || '登录失败')
    }
  } catch (error: any) {
    alert(error.message || '登录失败，请检查网络')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.login-page {
  min-height: 100vh;
  background: #f8f9fa;
}

.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 70vh;
  padding: 40px 20px;
}

.login-box {
  background: white;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
  width: 100%;
  max-width: 400px;
}

.login-title {
  text-align: center;
  font-size: 24px;
  font-weight: 700;
  color: #222;
  margin-bottom: 30px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  font-weight: 500;
  color: #333;
}

.form-group input {
  width: 100%;
  padding: 12px 16px;
  border: 1px solid #ddd;
  border-radius: 8px;
  font-size: 16px;
  box-sizing: border-box;
}

.login-btn {
  width: 100%;
  padding: 14px;
  background: linear-gradient(135deg, #4C7AE0 0%, #235CDC 100%);
  color: white;
  border: none;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  margin-top: 10px;
}

.login-btn:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.test-account {
  margin-top: 30px;
  padding: 20px;
  background: #f0f8ff;
  border-radius: 8px;
  font-size: 14px;
  color: #666;
}

.test-account p {
  margin: 4px 0;
}
</style> 