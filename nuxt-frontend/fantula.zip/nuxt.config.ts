// https://nuxt.com/docs/api/configuration/nuxt-config
export default defineNuxtConfig({
  // 兼容性日期
  compatibilityDate: '2025-07-01',
  
  // 开发工具
  devtools: { enabled: true },
  
  // 模块
  modules: [
    '@pinia/nuxt',
  ],

  // 组件自动导入
  components: true,
  
  // 应用配置
  app: {
    head: {
      title: '凡图拉 - 优质商品平台',
      meta: [
        { charset: 'utf-8' },
        { name: 'viewport', content: 'width=device-width, initial-scale=1' },
        { name: 'description', content: '凡图拉 - 提供优质商品和服务的综合性平台，专注于流媒体服务和数字产品' },
        { name: 'keywords', content: '凡图拉,流媒体,数字产品,Netflix,Disney+,Apple TV,技术支持,社区帮助' },
        { name: 'author', content: '凡图拉团队' },
        { name: 'robots', content: 'index, follow' },
        { name: 'googlebot', content: 'index, follow' },
        { name: 'language', content: 'zh-CN' },
        { name: 'revisit-after', content: '7 days' },
        // Open Graph
        { property: 'og:title', content: '凡图拉 - 优质商品平台' },
        { property: 'og:description', content: '凡图拉 - 提供优质商品和服务的综合性平台，专注于流媒体服务和数字产品' },
        { property: 'og:type', content: 'website' },
        { property: 'og:site_name', content: '凡图拉' },
        { property: 'og:locale', content: 'zh_CN' },
        { property: 'og:image', content: '/images/og-image.jpg' },
        { property: 'og:image:width', content: '1200' },
        { property: 'og:image:height', content: '630' },
        { property: 'og:url', content: 'https://yourdomain.com' },
        // Twitter Card
        { name: 'twitter:card', content: 'summary_large_image' },
        { name: 'twitter:title', content: '凡图拉 - 优质商品平台' },
        { name: 'twitter:description', content: '凡图拉 - 提供优质商品和服务的综合性平台，专注于流媒体服务和数字产品' },
        { name: 'twitter:image', content: '/images/og-image.jpg' }
      ],
      link: [
        { rel: 'icon', type: 'image/x-icon', href: '/favicon.ico' },
        { rel: 'canonical', href: 'https://yourdomain.com' },
        { rel: 'alternate', hreflang: 'zh-CN', href: 'https://yourdomain.com' },
        { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
        { rel: 'dns-prefetch', href: 'https://api.yourdomain.com' }
      ]
    }
  },
  

  
  // 运行时配置
  runtimeConfig: {
    // 私有配置（仅在服务端可用）
    apiSecret: process.env.API_SECRET,
    
    // 公共配置（客户端和服务端都可用）
    public: {
      apiBase: 'https://fantula.com/api',
      appName: '凡图拉',
      siteUrl: 'https://fantula.com'
    }
  },
  
  // 代理配置
  nitro: {
    devProxy: {
      // 统一API代理地址为11000端口，匹配后端标准配置
      '/api': {
        target: process.env.API_BASE_URL || 'http://localhost:11000',
        changeOrigin: true,
        prependPath: true
      },
      '/product': {
        target: process.env.API_BASE_URL || 'http://localhost:11000',
        changeOrigin: true,
        prependPath: true
      },
      '/basic': {
        target: process.env.API_BASE_URL || 'http://localhost:11000',
        changeOrigin: true,
        prependPath: true
      },
      '/question': {
        target: process.env.API_BASE_URL || 'http://localhost:11000',
        changeOrigin: true,
        prependPath: true
      },
      '/sys': {
        target: process.env.API_BASE_URL || 'http://localhost:11000',
        changeOrigin: true,
        prependPath: true
      }
    },
    // 预渲染配置
    prerender: {
      crawlLinks: true,
      routes: ['/community', '/about-us', '/service', '/faq']
    }
  },
  
  // 构建配置
  build: {
    transpile: ['axios']
  },
  
  // 类型检查
  typescript: {
    strict: false,
    typeCheck: false
  },

  // 路由配置
  router: {
    options: {
      scrollBehaviorType: 'smooth'
    }
  },

  // SSR配置 - 启用服务端渲染
  ssr: true,
  
  // 确保客户端导航正常工作
  experimental: {
    payloadExtraction: false
  },

  // SEO 优化配置
  css: []
}) 