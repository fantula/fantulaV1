<template>
  <div class="modal-mask">
    <div class="wallet-recharge-modal">
      <div class="modal-header">
        <div class="modal-title">充值</div>
        <div class="modal-subtitle">为您的余额充值吧！</div>
        <button class="modal-close" @click="$emit('close')">×</button>
      </div>
      <div class="modal-content">
        <div class="section-label">充值</div>
        <div class="amount-options">
          <div v-for="(item, idx) in options" :key="item.value" :class="['amount-option', {active: selectedIdx===idx}]" @click="selectOption(idx)">
            <div class="amount-main">¥{{ item.value }}</div>
            <div class="amount-desc">送¥{{ item.bonus }}</div>
          </div>
          <div :class="['amount-option', 'custom-option', {active: selectedIdx===-1}]" @click="selectOption(-1)"><span>自定义</span></div>
        </div>
        <div class="custom-amount-row">
          <input v-model.number="inputValue" type="number" min="1" placeholder="请输入充值金额" :disabled="selectedIdx!==-1" />
        </div>
        <div class="section-label pay-label">选择支付方式</div>
        <div class="pay-methods">
          <div :class="['pay-method', payType==='alipay' ? 'active' : '']" @click="payType='alipay'">
            <div class="pay-method-content">
              <img class="pay-icon" src="/images/zhifu2.png" alt="支付宝" />
              <span>支付宝</span>
            </div>
          </div>
        </div>
        <button class="btn-confirm" @click="handleRecharge">立即充值</button>
      </div>
      <div class="modal-bottom-blank"></div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { ref } from 'vue'
const emits = defineEmits(['close'])
const options = [
  { value: 100, bonus: 20 },
  { value: 300, bonus: 60 },
  { value: 1000, bonus: 300 },
  { value: 200, bonus: 600 },
]
const selectedIdx = ref(0)
const inputValue = ref<number | null>(null)
const payType = ref('alipay')
function selectOption(idx:number) {
  selectedIdx.value = idx
  if(idx!==-1) inputValue.value = null
}
function handleRecharge() {
  // 充值逻辑
}
</script>
<style scoped>
.modal-mask {
  position: fixed;
  z-index: 2000;
  left: 0; top: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.12);
  display: flex;
  align-items: center;
  justify-content: center;
}
.wallet-recharge-modal {
  width: 820px;
  background: #fff;
  border-radius: 32px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(33,150,243,0.12);
  display: flex;
  flex-direction: column;
}
.modal-header {
  background: linear-gradient(135deg, #2196F3 0%, #2575FC 100%);
  padding: 32px 32px 18px 32px;
  position: relative;
  text-align: center;
}
.modal-title {
  font-size: 28px;
  font-weight: 700;
  color: #fff;
  margin-bottom: 8px;
}
.modal-subtitle {
  color: #e3f0ff;
  font-size: 16px;
  margin-bottom: 0;
}
.modal-close {
  position: absolute;
  top: 18px;
  right: 24px;
  background: none;
  border: none;
  font-size: 28px;
  color: #fff;
  cursor: pointer;
  line-height: 1;
  padding: 0 4px;
  border-radius: 4px;
  transition: background 0.2s;
}
.modal-content {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 32px 32px 0 32px;
  gap: 18px;
}
.section-label {
  font-size: 20px;
  color: #222;
  font-weight: 700;
  margin-bottom: 18px;
  align-self: flex-start;
}
.amount-options {
  display: flex;
  gap: 18px;
  width: 100%;
  justify-content: flex-start;
  margin-bottom: 8px;
}
.amount-option {
  background: #fff;
  border: 2px solid #2196F3;
  border-radius: 18px;
  padding: 18px 32px;
  min-width: 90px;
  display: flex;
  flex-direction: column;
  align-items: center;
  cursor: pointer;
  font-size: 22px;
  font-weight: 700;
  color: #222;
  transition: border 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(33,150,243,0.04);
  justify-content: center;
}
.amount-option.active {
  background: #f0f7ff;
  border-color: #2575FC;
  color: #2575FC;
}
.amount-desc {
  font-size: 15px;
  color: #1BC700;
  font-weight: 500;
  margin-top: 4px;
}
.custom-amount-row {
  width: 100%;
  margin-bottom: 8px;
}
.custom-amount-row input {
  width: 100%;
  border: none;
  border-radius: 22px;
  background: #f8f9fa;
  font-size: 18px;
  padding: 16px 18px;
  color: #222;
  outline: none;
  box-shadow: 0 1px 4px rgba(33,150,243,0.04);
}
.pay-label {
  margin-top: 18px;
  margin-bottom: 8px;
}
.pay-methods {
  width: 100%;
  display: flex;
  gap: 18px;
  margin-bottom: 18px;
  justify-content: flex-start;
}
.pay-method {
  width: 220px;
  height: 56px;
  background: #fff;
  border: 2px solid #2196F3;
  border-radius: 14px;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  font-size: 18px;
  font-weight: 700;
  color: #222;
  transition: border 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 8px rgba(33,150,243,0.04);
  position: relative;
}
.pay-method-content {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
}
.pay-method.active {
  background: #f0f7ff;
  border-color: #2575FC;
  color: #2575FC;
}
.pay-icon {
  width: 32px;
  height: 32px;
  margin-right: 18px;
  margin-left: 8px;
  flex-shrink: 0;
}
.pay-method span {
  flex: none;
  text-align: center;
  display: block;
  font-size: 20px;
}
.btn-confirm {
  width: 60%;
  background: linear-gradient(90deg, #2196F3 0%, #2575FC 100%);
  color: #fff;
  border: none;
  border-radius: 22px;
  padding: 0;
  height: 44px;
  font-size: 17px;
  font-weight: 700;
  cursor: pointer;
  margin: -8px auto 0 auto;
  box-shadow: 0 2px 8px rgba(33,150,243,0.10);
  transition: background 0.2s;
  display: block;
}
.btn-confirm:disabled {
  background: #b3c6e6;
  cursor: not-allowed;
}
.custom-option {
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  min-height: 72px;
  min-width: 120px;
}
.custom-option span {
  width: 100%;
  text-align: center;
  font-size: 22px;
  font-weight: 700;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 100%;
}
.modal-bottom-blank {
  width: 100%;
  height: 48px;
  background: #fff;
  border-bottom-left-radius: 32px;
  border-bottom-right-radius: 32px;
}
</style> 