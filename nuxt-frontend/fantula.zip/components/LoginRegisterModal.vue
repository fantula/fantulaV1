<template>
  <div v-if="visible" class="modal-mask" @click.self="close">
    <div class="login-modal">
      <!-- 上半部分 蓝色区域 -->
      <div class="modal-header">
        <div class="modal-header-inner">
          <div class="modal-title">凡图拉</div>
          <div class="modal-subtitle">欢迎回来，请登录您的账户</div>
          <div class="modal-tabs">
            <button :class="['tab-btn', {active: mode==='login'}]" @click="mode='login'">登录</button>
            <button :class="['tab-btn', {active: mode==='register'}]" @click="mode='register'">注册</button>
          </div>
          <button class="modal-close" @click="close">×</button>
        </div>
      </div>
      <!-- 下半部分 白色区域 -->
      <div class="modal-body">
        <div class="modal-form-area">
          <div v-if="mode==='login'" class="modal-form-tabs">
            <button :class="['form-tab', {active: loginType==='password'}]" @click="loginType='password'">密码登录</button>
            <button :class="['form-tab', {active: loginType==='code'}]" @click="loginType='code'">验证码登录</button>
          </div>
          <form v-if="mode==='login' && loginType==='password'" @submit.prevent="onLogin">
            <div class="form-group">
              <label>邮箱地址</label>
              <input v-model="loginForm.email" type="email" placeholder="请输入您的邮箱" required />
            </div>
            <div class="form-group">
              <label>密码</label>
              <input v-model="loginForm.password" type="password" placeholder="请输入密码" required />
            </div>
            <div class="form-row">
              <label><input type="checkbox" v-model="loginForm.remember" /> 记住我</label>
              <a class="forgot-link" @click.prevent="onForgot">忘记密码？</a>
            </div>
            <div class="form-row">
              <label><input type="checkbox" v-model="loginForm.agree" required /> 我已阅读并同意 <NuxtLink to="/privacy" target="_blank">《隐私协议》</NuxtLink> 和 <NuxtLink to="/policy" target="_blank">《用户政策》</NuxtLink></label>
            </div>
            <button class="submit-btn" type="submit">登录</button>
          </form>
          <form v-else-if="mode==='login' && loginType==='code'" @submit.prevent="onLoginCode">
            <div class="form-group">
              <label>邮箱地址</label>
              <input v-model="loginCodeForm.email" type="email" placeholder="请输入您的邮箱" required />
            </div>
            <div class="form-group code-group">
              <input v-model="loginCodeForm.code" type="text" placeholder="请输入验证码" required />
              <button class="code-btn-inside" type="button" :disabled="codeTimer>0" @click="sendCode('login')">{{ codeTimer>0 ? codeTimer+'s' : '获取验证码' }}</button>
            </div>
            <div class="form-row">
              <label><input type="checkbox" v-model="loginCodeForm.remember" /> 记住我</label>
            </div>
            <div class="form-row">
              <label><input type="checkbox" v-model="loginCodeForm.agree" required /> 我已阅读并同意 <NuxtLink to="/privacy" target="_blank">《隐私协议》</NuxtLink> 和 <NuxtLink to="/policy" target="_blank">《用户政策》</NuxtLink></label>
            </div>
            <button class="submit-btn" type="submit">登录</button>
          </form>
          <form v-else-if="mode==='register'" @submit.prevent="onRegister">
            <div class="form-group">
              <label>邮箱地址</label>
              <input v-model="registerForm.email" type="email" placeholder="请输入您的邮箱" required />
            </div>
            <div class="form-group code-group">
              <input v-model="registerForm.code" type="text" placeholder="请输入验证码" required />
              <button class="code-btn-inside" type="button" :disabled="codeTimer>0" @click="sendCode('register')">{{ codeTimer>0 ? codeTimer+'s' : '获取验证码' }}</button>
            </div>
            <div class="form-group">
              <label>密码</label>
              <input v-model="registerForm.password" type="password" placeholder="请输入密码" required />
            </div>
            <div class="form-group">
              <label>邀请码（选填）</label>
              <input v-model="registerForm.inviteId" type="text" placeholder="请输入邀请码" />
            </div>
            <div class="form-row">
              <label><input type="checkbox" v-model="registerForm.agree" required /> 我已阅读并同意 <NuxtLink to="/privacy" target="_blank">《隐私协议》</NuxtLink> 和 <NuxtLink to="/policy" target="_blank">《用户政策》</NuxtLink></label>
            </div>
            <button class="submit-btn" type="submit">注册</button>
          </form>
        </div>
        <div class="other-login-area">
          <div class="other-login-title">其他方式登录</div>
          <div class="other-login-icons">
            <button class="icon-btn" @click="oauth('google')"><img src="/images/oauth-google.png" alt="Google" /></button>
            <button class="icon-btn" @click="oauth('facebook')"><img src="/images/oauth-facebook.png" alt="Facebook" /></button>
            <button class="icon-btn" @click="oauth('github')"><img src="/images/oauth-github.png" alt="GitHub" /></button>
          </div>
        </div>
      </div>
    </div>
    <!-- 遮罩层 -->
  </div>
  <template v-if="showPrivacyDialog">
    <div class="dialog-mask" @click.self="closeDialog('privacy')">
      <div class="dialog-box">
        <div class="dialog-title">隐私协议</div>
        <div class="dialog-content">这里是隐私协议内容...</div>
        <button class="dialog-close" @click="closeDialog('privacy')">关闭</button>
      </div>
    </div>
  </template>
  <template v-if="showPolicyDialog">
    <div class="dialog-mask" @click.self="closeDialog('policy')">
      <div class="dialog-box">
        <div class="dialog-title">用户政策</div>
        <div class="dialog-content">这里是用户政策内容...</div>
        <button class="dialog-close" @click="closeDialog('policy')">关闭</button>
      </div>
    </div>
  </template>
  <template v-if="showForgotDialog">
    <div class="dialog-mask" @click.self="closeDialog('forgot')">
      <div class="dialog-box">
        <div class="dialog-title">找回密码</div>
        <form @submit.prevent="onForgotSubmit">
          <div class="form-group">
            <label>邮箱地址</label>
            <input v-model="forgotForm.email" type="email" placeholder="请输入您的邮箱" required />
          </div>
          <div class="form-group code-group">
            <label>验证码</label>
            <input v-model="forgotForm.code" type="text" placeholder="请输入验证码" required />
            <button class="code-btn" type="button" :disabled="forgotCodeTimer>0" @click="sendForgotCode">{{ forgotCodeTimer>0 ? forgotCodeTimer+'s' : '获取验证码' }}</button>
          </div>
          <div class="form-group">
            <label>新密码</label>
            <input v-model="forgotForm.password" type="password" placeholder="请输入新密码" required />
          </div>
          <button class="submit-btn" type="submit">重置密码</button>
        </form>
        <button class="dialog-close" @click="closeDialog('forgot')">关闭</button>
      </div>
    </div>
  </template>
  <div v-if="message" class="modal-message">{{ message }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useUserStore } from '@/stores/user'
import { http } from '@/utils/request'
const props = defineProps<{ visible: boolean }>()
const emit = defineEmits(['close'])

const mode = ref<'login'|'register'>('login')
const loginType = ref<'password'|'code'>('password')
const codeTimer = ref(0)
let codeInterval: any = null

const loginForm = ref({ email: '', password: '', remember: false, agree: false })
const loginCodeForm = ref({ email: '', code: '', password: '', remember: false, agree: false })
const registerForm = ref({ email: '', code: '', password: '', inviteId: '', agree: false })

const showPrivacyDialog = ref(false)
const showPolicyDialog = ref(false)
const showForgotDialog = ref(false)
const forgotForm = ref({ email: '', code: '', password: '' })
const forgotCodeTimer = ref(0)
let forgotCodeInterval: any = null
const message = ref('')
const loading = ref(false)

function close() {
  emit('close')
}
function showPrivacy() {
  showPrivacyDialog.value = true
}
function showPolicy() {
  showPolicyDialog.value = true
}
function onForgot() {
  showForgotDialog.value = true
}
function sendCode(type: 'login'|'register') {
  if (codeTimer.value > 0) return
  const email = type==='register' ? registerForm.value.email : loginCodeForm.value.email
  if (!email) { message.value = '请输入邮箱'; return }
  
  // 🎨 前端UI设计阶段 - 模拟验证码发送（已注释，用于检查页面功能）
  /*
  message.value = '验证码已发送（开发模式）'
  codeTimer.value = 60
  codeInterval = setInterval(() => {
    codeTimer.value--
    if (codeTimer.value <= 0) clearInterval(codeInterval)
  }, 1000)
  */
  
  // ✅ 真实API调用（已启用）
  loading.value = true
  http.get(`/product/common/code`, { email })
    .then(() => {
      message.value = '验证码已发送'
      codeTimer.value = 60
      codeInterval = setInterval(() => {
        codeTimer.value--
        if (codeTimer.value <= 0) clearInterval(codeInterval)
      }, 1000)
    })
    .catch(err => { message.value = err.message || '验证码发送失败' })
    .finally(() => { loading.value = false })
}

function sendForgotCode() {
  if (forgotCodeTimer.value > 0) return
  if (!forgotForm.value.email) { message.value = '请输入邮箱'; return }
  
  // 🎨 前端UI设计阶段 - 模拟验证码发送（已注释，用于检查页面功能）
  /*
  message.value = '验证码已发送（开发模式）'
  forgotCodeTimer.value = 60
  forgotCodeInterval = setInterval(() => {
    forgotCodeTimer.value--
    if (forgotCodeTimer.value <= 0) clearInterval(forgotCodeInterval)
  }, 1000)
  */
  
  // ✅ 真实API调用（已启用）
  loading.value = true
  http.get(`/product/common/code`, { email: forgotForm.value.email })
    .then(() => {
      message.value = '验证码已发送'
      forgotCodeTimer.value = 60
      forgotCodeInterval = setInterval(() => {
        forgotCodeTimer.value--
        if (forgotCodeTimer.value <= 0) clearInterval(forgotCodeInterval)
      }, 1000)
    })
    .catch(err => { message.value = err.message || '验证码发送失败' })
    .finally(() => { loading.value = false })
}

async function onLogin() {
  if (!loginForm.value.email || !loginForm.value.password) { message.value = '请填写完整'; return }
  if (!loginForm.value.agree) { message.value = '请勾选协议'; return }
  
  // 🎨 前端UI设计阶段 - 模拟登录（已注释，用于检查页面功能）
  /*
  message.value = '登录成功（开发模式）'
  const mockUser = {
    id: 1,
    username: loginForm.value.email?.split('@')[0] || 'dev_user',
    email: loginForm.value.email,
    avatar: '/images/default-avatar.png'
  }
  
  if (loginForm.value.remember) localStorage.setItem('token', 'mock-token-' + Date.now())
  useUserStore().setUser(mockUser, 'mock-token-' + Date.now())
  close()
  location.reload()
  */
  
  // ✅ 真实API调用（已启用）
  loading.value = true
  try {
    const res = await http.post('/product/common/mail/login', loginForm.value)
    if (res.code === 0 && res.data) {
      if (loginForm.value.remember) localStorage.setItem('token', res.data.tokenValue)
      useUserStore().setUser(res.data, res.data.tokenValue)
      message.value = '登录成功'
      close()
      location.reload()
    } else {
      message.value = res.msg || '登录失败'
    }
  } catch (e: any) {
    message.value = e.message || '登录失败'
  } finally {
    loading.value = false
  }
}

async function onLoginCode() {
  if (!loginCodeForm.value.email || !loginCodeForm.value.code) { message.value = '请填写完整'; return }
  if (!loginCodeForm.value.agree) { message.value = '请勾选协议'; return }
  
  // 🎨 前端UI设计阶段 - 模拟验证码登录（已注释，用于检查页面功能）
  /*
  message.value = '验证码登录成功（开发模式）'
  const mockUser = {
    id: 1,
    username: loginCodeForm.value.email?.split('@')[0] || 'dev_user',
    email: loginCodeForm.value.email,
    avatar: '/images/default-avatar.png'
  }
  
  if (loginCodeForm.value.remember) localStorage.setItem('token', 'mock-token-' + Date.now())
  useUserStore().setUser(mockUser, 'mock-token-' + Date.now())
  close()
  location.reload()
  */
  
  // ✅ 真实API调用（已启用）
  loading.value = true
  try {
    const res = await http.post('/product/common/mail/codeLogin', loginCodeForm.value)
    if (res.code === 0 && res.data) {
      if (loginCodeForm.value.remember) localStorage.setItem('token', res.data.tokenValue)
      useUserStore().setUser(res.data, res.data.tokenValue)
      message.value = '登录成功'
      close()
      location.reload()
    } else {
      message.value = res.msg || '验证码登录失败'
    }
  } catch (e: any) {
    message.value = e.message || '验证码登录失败'
  } finally {
    loading.value = false
  }
}

async function onRegister() {
  if (!registerForm.value.email || !registerForm.value.code || !registerForm.value.password) { message.value = '请填写完整'; return }
  if (!registerForm.value.agree) { message.value = '请勾选协议'; return }
  
  // 🎨 前端UI设计阶段 - 模拟注册成功（已注释，用于检查页面功能）
  /*
  console.warn('注册功能暂未实现，使用模拟返回')
  const mockUser = {
    id: 1,
    username: registerForm.value.email?.split('@')[0] || 'dev_user',
    email: registerForm.value.email,
    avatar: '/images/default-avatar.png'
  }
  return { success: true, data: { message: '注册功能开发中' } }
  */
  
  // ✅ 真实API调用（已启用）
  loading.value = true
  try {
    const res = await http.post('/product/common/mail/code', registerForm.value)
    if (res.code === 0 && res.data) {
      message.value = '注册成功，已自动登录'
      localStorage.setItem('token', res.data.tokenValue)
      useUserStore().setUser(res.data, res.data.tokenValue)
      close()
      location.reload()
    } else {
      message.value = res.msg || '注册失败'
    }
  } catch (e: any) {
    message.value = e.message || '注册失败'
  } finally {
    loading.value = false
  }
}
function oauth(type: string) {
  window.location.href = `/api/oauth/${type}`
}
function closeDialog(type: string) {
  if (type==='privacy') showPrivacyDialog.value = false
  if (type==='policy') showPolicyDialog.value = false
  if (type==='forgot') showForgotDialog.value = false
}
async function onForgotSubmit() {
  if (!forgotForm.value.email || !forgotForm.value.code || !forgotForm.value.password) { message.value = '请填写完整'; return }
  
  // 开发模式下的模拟密码重置
  message.value = '密码重置成功，请登录（开发模式）'
  showForgotDialog.value = false
  
  // 真实API调用（已注释，用于生产环境）
  /*
  loading.value = true
  try {
    // 假设后端找回密码接口同注册接口
    const res = await http.post('/product/common/mail/code', { ...forgotForm.value })
    if (res.code === 0) {
      message.value = '密码重置成功，请登录'
      showForgotDialog.value = false
    } else {
      message.value = res.msg || '重置失败'
    }
  } catch (e: any) {
    message.value = e.message || '重置失败'
  } finally {
    loading.value = false
  }
  */
}
</script>

<style scoped>
.modal-mask {
  position: fixed;
  z-index: 9999;
  left: 0; top: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.25);
  display: flex;
  align-items: center;
  justify-content: center;
}
.login-modal {
  width: 450px;
  min-width: 450px;
  max-width: 450px;
  height: 824px;
  background: rgba(255,255,255,0.95);
  border-radius: 18px;
  box-shadow: 0 8px 32px 0 rgba(0,0,0,0.18);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.modal-header {
  width: 100%;
  height: 207px;
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  border-radius: 18px 18px 0 0;
  position: relative;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
.modal-header-inner {
  width: 100%;
  padding: 32px 32px 0 32px;
  position: relative;
}
.modal-title {
  font-size: 38px;
  font-weight: bold;
  color: #fff;
  text-align: center;
  margin-bottom: 8px;
}
.modal-subtitle {
  font-size: 18px;
  color: #e0eaff;
  text-align: center;
  margin-bottom: 24px;
}
.modal-tabs {
  display: flex;
  justify-content: center;
  gap: 0;
  margin-bottom: 8px;
  background: rgba(255,255,255,0.18);
  border-radius: 28px;
  width: 264px;
  height: 56px;
  margin-left: auto;
  margin-right: auto;
  box-shadow: 0 2px 8px rgba(59,130,246,0.04);
  position: relative;
}
.tab-btn {
  font-size: 18px;
  width: 132px;
  height: 56px;
  border-radius: 28px;
  border: none;
  background: transparent;
  color: #fff;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s, color 0.2s;
  z-index: 1;
}
.tab-btn.active {
  background: #fff;
  color: #2563EB;
  box-shadow: 0 2px 8px rgba(59,130,246,0.08);
}
.modal-close {
  position: absolute;
  right: 24px;
  top: 24px;
  font-size: 28px;
  color: #fff;
  background: none;
  border: none;
  cursor: pointer;
  z-index: 2;
}
.modal-body {
  width: 100%;
  height: 617px;
  background: #fff;
  border-radius: 0 0 0 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  overflow: hidden;
}
.modal-form-area {
  margin-top: 24px;
  width: 396px;
  margin-left: auto;
  margin-right: auto;
}
.modal-form-tabs {
  display: flex;
  gap: 32px;
  margin-bottom: 24px;
  border-bottom: 2px solid #e6e6e6;
}
.form-tab {
  font-size: 18px;
  background: none;
  border: none;
  color: #222;
  font-weight: 500;
  padding: 8px 0;
  cursor: pointer;
  border-bottom: 2px solid transparent;
  transition: border-color 0.2s;
}
.form-tab.active {
  color: #2563EB;
  border-bottom: 2px solid #2563EB;
}
.form-group {
  margin-bottom: 18px;
  display: flex;
  flex-direction: column;
  width: 100%;
}
.form-group label {
  font-size: 15px;
  color: #222;
  margin-bottom: 6px;
}
.form-group input {
  width: 360px;
  height: 49px;
  border-radius: 11px;
  border: 2px solid #E0E0E0;
  background: #fff;
  padding: 0 14px;
  font-size: 16px;
  outline: none;
  transition: border 0.2s;
  margin-left: auto;
  margin-right: auto;
}
.form-group input:focus {
  border: 2px solid #2563EB;
}
.code-group {
  position: relative;
  display: flex;
  align-items: center;
  width: 100%;
}
.code-group input {
  width: 360px;
  height: 49px;
  border-radius: 11px;
  border: 2px solid #E0E0E0;
  background: #fff;
  padding: 0 110px 0 14px;
  font-size: 16px;
  outline: none;
  transition: border 0.2s;
  margin-left: auto;
  margin-right: auto;
}
.code-btn-inside {
  position: absolute;
  right: 20px;
  top: 7px;
  height: 35px;
  padding: 0 14px;
  border-radius: 8px;
  border: none;
  background: #2563EB;
  color: #fff;
  font-size: 15px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
  z-index: 2;
}
.code-btn-inside:disabled {
  background: #bcd2fa;
  cursor: not-allowed;
}
.form-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  font-size: 14px;
  color: #888;
  width: 100%;
}
.forgot-link {
  color: #2563EB;
  cursor: pointer;
  text-decoration: underline;
  font-size: 14px;
  margin-left: auto;
  align-self: center;
}
.agree-area {
  width: 100%;
  height: 46px;
  background: #F8F9FF;
  border-radius: 11px;
  display: flex;
  align-items: center;
  padding-left: 12px;
  margin-bottom: 18px;
  font-size: 14px;
  color: #888;
  box-shadow: 0 2px 8px rgba(59,130,246,0.04);
}
.submit-btn {
  width: 100%;
  height: 48px;
  background: linear-gradient(90deg, #3B82F6 0%, #2563EB 100%);
  color: #fff;
  font-size: 20px;
  font-weight: 600;
  border: none;
  border-radius: 12px;
  margin-top: 18px;
  margin-bottom: 32px;
  box-shadow: 0 2px 8px rgba(59,130,246,0.08);
  cursor: pointer;
  transition: background 0.2s;
}
.submit-btn:hover {
  background: linear-gradient(90deg, #2563EB 0%, #3B82F6 100%);
}
.other-login-area {
  width: 396px;
  height: 56px;
  margin: 0 auto;
  text-align: center;
  border-top: none;
  padding-top: 0;
  display: flex;
  flex-direction: column;
  justify-content: flex-end;
}
.other-login-title {
  width: 100%;
  height: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 12px auto;
  font-size: 15px;
  color: #888;
  position: relative;
}
.other-login-title::before,
.other-login-title::after {
  content: '';
  display: block;
  flex: 1;
  height: 1.5px;
  background: rgba(59,130,246,0.12);
  margin: 0 12px;
  border-radius: 1px;
}
.other-login-icons {
  display: flex;
  justify-content: center;
  gap: 18px;
}
.icon-btn {
  width: 48px;
  height: 48px;
  border-radius: 10px;
  border: 1.5px dashed #e6e6e6;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: border 0.2s;
}
.icon-btn:hover {
  border: 1.5px solid #2563EB;
}
.icon-btn img {
  width: 28px;
  height: 28px;
}
.dialog-mask {
  position: fixed;
  z-index: 9999;
  left: 0; top: 0; right: 0; bottom: 0;
  background: rgba(0,0,0,0.25);
  display: flex;
  align-items: center;
  justify-content: center;
}
.dialog-box {
  width: 450px;
  background: #fff;
  border-radius: 18px;
  box-shadow: 0 8px 32px 0 rgba(0,0,0,0.18);
  overflow: hidden;
  display: flex;
  flex-direction: column;
}
.dialog-title {
  width: 100%;
  height: 207px;
  background: linear-gradient(135deg, #3B82F6 0%, #2563EB 100%);
  border-radius: 18px 18px 0 0;
  position: relative;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}
.dialog-title h1 {
  font-size: 38px;
  font-weight: bold;
  color: #fff;
  text-align: center;
  margin-bottom: 8px;
}
.dialog-content {
  padding: 32px;
  flex-grow: 1;
}
.dialog-close {
  position: absolute;
  right: 24px;
  top: 24px;
  font-size: 28px;
  color: #fff;
  background: none;
  border: none;
  cursor: pointer;
  z-index: 2;
}
.modal-message {
  position: fixed;
  top: 20px;
  right: 20px;
  padding: 12px 24px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  font-size: 16px;
  font-weight: 500;
  color: #222;
  z-index: 9999;
}
</style> 