<template>
  <section class="goods-section">
    <div class="goods-inner">
      <!-- 顶部Tab/按钮区 -->
      <div class="goods-tabs-wrap">
        <div class="goods-tabs">
          <div v-for="(tab, idx) in tabs" :key="tab.key" :class="['goods-tab', { active: tab.key === activeTab }]" @click="selectTab(tab.key)">
            <div class="tab-icon"></div>
            <div class="tab-label">{{ tab.label }}</div>
          </div>
        </div>
        <div class="tab-underline" :style="underlineStyle"></div>
      </div>
      <!-- 商品网格区 -->
      <div class="goods-grid">
        <div v-for="(goods, index) in filteredGoods" :key="goods.id" :class="['goods-card', { 'first-card': index === 0 }]" @click="goToDetail(goods)" style="cursor: pointer;">
          <div v-if="goods.status === 1" class="goods-hot-tag">热卖</div>
          
          <!-- 默认布局 -->
          <div class="goods-default-layout">
            <div class="goods-image special-image">
              <img :src="goods.image || '/images/netflix.png'" :alt="goods.name" class="special-img" />
            </div>
            <div class="goods-info">
              <div class="goods-title-row2">
                <span class="goods-name2">{{ goods.name }}</span>
                <span class="goods-recent">🕒 XX分钟前购买过</span>
                <span class="goods-help"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="8" fill="#EDF3FF"/><text x="8" y="12" text-anchor="middle" font-size="12" fill="#235CDC">?</text></svg></span>
              </div>
              <div class="goods-meta2">
                <span class="goods-price-label">券后</span><span class="goods-price2">{{ goods.price }}</span><span class="goods-price-unit">/12个月</span>
              </div>
              <div class="goods-sales-row2">
                <span>销量: {{ goods.sales || '2.5万+' }}</span>
                <span>好评: 98%</span>
              </div>
              <div class="goods-features2 special-features">
                <span class="goods-feature2">全球解锁</span>
                <span class="goods-feature2">4K高清</span>
                <span class="goods-feature2">支持杜比</span>
                <span class="goods-feature2">单月起售</span>
              </div>
              <div class="goods-promo2 special-promo">
                <img src="/images/cut.png" alt="限时折扣9折" class="cut-img" />
              </div>
            </div>
          </div>

          <!-- 悬停时的特殊布局（仅第一个商品） -->
          <div v-if="index === 0" class="goods-hover-layout">
            <!-- 顶部logo和图标区域 -->
            <div class="hover-header">
              <div class="hover-app-icon">
                <img src="/images/netflix.png" alt="Netflix" class="hover-icon-img" />
              </div>
            </div>
            
            <!-- 应用信息区域 -->
            <div class="hover-app-info">
              <div class="hover-app-name">Netflix</div>
              <div class="hover-app-meta">
                <div class="hover-user-avatars">
                  <img src="/images/head1.png" alt="用户1" class="hover-avatar" />
                  <img src="/images/head2.png" alt="用户2" class="hover-avatar" />
                  <img src="/images/head3.png" alt="用户3" class="hover-avatar" />
                </div>
                <span class="hover-purchased-text">谁购买过</span>
                <div class="hover-verified-icon">
                  <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                    <circle cx="10" cy="10" r="10" fill="#235CDC"/>
                    <text x="10" y="14" text-anchor="middle" font-size="12" fill="white">?</text>
                  </svg>
                </div>
              </div>
            </div>

            <!-- 价格区域 -->
            <div class="hover-price-section">
              <span class="hover-price-label">券后</span>
              <span class="hover-price-number">162</span>
              <span class="hover-price-unit">/12个月</span>
            </div>

            <!-- 销量和好评区域 -->
            <div class="hover-stats">
              <span class="hover-sales">销量: 2.5万+</span>
              <span class="hover-rating">好评: 98%</span>
            </div>

            <!-- 功能标签区域 -->
            <div class="hover-features">
              <span class="hover-feature-tag feature-global">全球解锁</span>
              <span class="hover-feature-tag feature-4k">4K高清</span>
              <span class="hover-feature-tag feature-dolby">支持杜比</span>
              <span class="hover-feature-tag feature-monthly">单月起售</span>
            </div>

            <!-- 购买按钮 -->
            <div class="hover-buy-section">
              <button class="hover-buy-btn" @click.stop="buyNow(goods)">购买</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <OrderPayModal
      v-if="showPayModal"
      :shopLogo="payGoods.shopLogo"
      :shopName="payGoods.shopName"
      :shopDesc="payGoods.shopDesc"
      :orderId="payGoods.orderId"
      :price="payGoods.price"
      :countdown="payCountdown"
      @close="showPayModal = false"
      @timeout="handlePayTimeout"
      @paySuccess="handlePaySuccess"
    />
  </section>
</template>

<script setup lang="ts">
import { ref, computed, nextTick, onMounted } from 'vue'
import type { Goods } from '@/types/api'
import { useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { useModalStore } from '@/stores/modal'
import OrderPayModal from './OrderPayModal.vue'
const props = defineProps<{ goodsList: Goods[] }>()
const userStore = useUserStore()
const modalStore = useModalStore()

// 顶部Tab按钮数据
const tabs = [
  { key: 'all', label: '百万补贴' },
  { key: 'recommend', label: '推荐' },
  { key: 'video', label: '影音' },
  { key: 'ai', label: 'AI服务' },
  { key: 'study', label: '学习' },
  { key: 'value', label: '增值' }
]
const activeTab = ref('all')
function selectTab(key: string) {
  activeTab.value = key
  nextTick(updateUnderline)
}
const activeTabIndex = computed(() => tabs.findIndex(t => t.key === activeTab.value))

// 下划线动态宽度与位置
const tabRefs = ref<HTMLElement[]>([])
const underlineStyle = ref({ left: '0px', width: '120px' })
function updateUnderline() {
  nextTick(() => {
    const activeIndex = activeTabIndex.value
    const el = tabRefs.value && tabRefs.value.length > activeIndex ? tabRefs.value[activeIndex] : null
    if (el) {
      const icon = el.querySelector('.tab-icon') as HTMLElement
      if (icon) {
        const parentRect = el.parentElement!.getBoundingClientRect()
        const iconRect = icon.getBoundingClientRect()
        underlineStyle.value = {
          left: `${iconRect.left - parentRect.left}px`,
          width: `${iconRect.width}px`
        }
      }
    }
  })
}
onMounted(() => {
  updateUnderline()
})

// 过滤商品（此处仅演示，实际可按tab分类）
const filteredGoods = computed(() => props.goodsList)
// 立即购买功能
const showPayModal = ref(false)
const payGoods = ref<any>(null)
const payCountdown = 900 // 15分钟
const buyNow = (goods: any) => {
  // 检查用户是否已登录
  if (!userStore.isLoggedIn) {
    console.log('🔐 用户未登录，打开登录弹窗')
    modalStore.openLogin()
    return
  }
  
  console.log('💳 用户已登录，打开支付弹窗')
  payGoods.value = goods
  showPayModal.value = true
}
function handlePayClose() {
  showPayModal.value = false
}
function handlePayTimeout() {
  showPayModal.value = false
  // 可在此处触发订单取消逻辑
}

const router = useRouter()
const goToDetail = (goods: Goods) => {
  router.push(`/goods/${goods.id}`)
}

// 支付成功处理
const handlePaySuccess = (paymentInfo: any) => {
  console.log('🛒 商品列表页支付成功！', paymentInfo)
  
  // 添加新订单到订单列表
  const orderResult = userStore.addOrder({
    orderId: paymentInfo.orderId,
    title: payGoods.value?.name || payGoods.value?.title || '未知商品',
    amount: paymentInfo.amount,
    payType: paymentInfo.payType,
    productImage: payGoods.value?.image || payGoods.value?.logo
  })
  
  if (orderResult.success) {
    console.log('✅ 订单已成功添加到我的订单列表')
    alert(`🎉 支付成功！\n商品：${payGoods.value?.name || payGoods.value?.title}\n订单号：${paymentInfo.orderId}\n金额：¥${paymentInfo.amount}\n\n订单已添加到【我的订单】`)
  } else {
    alert(`🎉 支付成功！\n商品：${payGoods.value?.name || payGoods.value?.title}\n订单号：${paymentInfo.orderId}\n金额：¥${paymentInfo.amount}`)
  }
  
  // 关闭支付弹窗
  showPayModal.value = false
}
</script>

<style scoped>
.goods-section {
  width: 100vw;
  min-width: 1211px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  margin-bottom: 40px;
}
.goods-inner {
  width: 1211px;
  min-height: 997px;
  background: transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.goods-tabs-wrap {
  width: 100%;
  background: #fff;
  border-radius: 24px;
  box-shadow: 0 4px 24px 0px rgba(35,92,220,0.06);
  padding: 32px 0 0 0;
  margin-bottom: 32px;
  position: relative;
  min-height: 140px;
  display: flex;
  justify-content: center;
}
.goods-tabs {
  display: flex;
  align-items: flex-end;
  justify-content: center;
  gap: 24px;
  padding: 0 0 8px 0;
  position: relative;
  z-index: 2;
}
.goods-tab {
  width: 120px;
  height: 120px;
  background: #fff;
  border-radius: 16px;
  border: 2px solid transparent;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: border 0.2s, box-shadow 0.2s;
  position: relative;
  box-sizing: border-box;
}
.goods-tab.active {
  border: 2px solid #235CDC;
  box-shadow: 0 4px 16px 0px rgba(35,92,220,0.08);
}
.tab-icon {
  width: 48px;
  height: 48px;
  background: #e0e7ef;
  border-radius: 50%;
  margin-bottom: 12px;
}
.tab-label {
  font-size: 16px;
  color: #666;
  text-align: center;
  white-space: nowrap;
  font-weight: 500;
}
.goods-tab.active .tab-label {
  color: #235CDC;
  font-weight: bold;
}
.tab-underline {
  display: none;
}
/* 商品区原有样式保留 */
.goods-grid {
  width: 100%;
  display: grid;
  grid-template-columns: repeat(4, 276px);
  grid-auto-rows: 381px;
  gap: 32px 27px;
  justify-content: center;
}
.goods-card {
  width: 276px;
  height: 381px;
  background: #fff;
  border-radius: 20px;
  box-shadow: 0px 5px 15px 0px rgba(0,0,0,0.08);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative;
  transition: box-shadow 0.2s, transform 0.2s;
}
.goods-card:hover {
  box-shadow: 0px 12px 32px 0px rgba(0,0,0,0.12);
  transform: translateY(-4px) scale(1.02);
}
.goods-image {
  width: 100%;
  height: 120px;
  background: #f5f5f5;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 20px 20px 0 0;
  overflow: hidden;
}
.goods-image img {
  width: 80px;
  height: 80px;
  object-fit: contain;
  border-radius: 12px;
}
.goods-info {
  flex: 1;
  padding: 18px 18px 12px 18px;
  display: flex;
  flex-direction: column;
  justify-content: flex-start;
}
.goods-title-row2 {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  gap: 6px;
  margin-bottom: 4px;
}
.goods-name2 {
  font-size: 20px;
  font-weight: 600;
  color: #222;
  margin-right: 4px;
}
.goods-recent {
  font-size: 12px;
  color: #b0b0b0;
  margin-right: 2px;
}
.goods-help {
  display: flex;
  align-items: center;
  margin-left: 2px;
}
.goods-meta2 {
  font-size: 16px;
  margin-bottom: 4px;
  display: flex;
  align-items: baseline;
  gap: 2px;
}
.goods-price-label {
  color: #FF3B30;
  font-weight: bold;
  font-size: 16px;
}
.goods-price2 {
  color: #FF3B30;
  font-size: 22px;
  font-weight: bold;
  margin: 0 2px;
}
.goods-price-unit {
  color: #b0b0b0;
  font-size: 16px;
  font-weight: 500;
}
.goods-sales-row2 {
  font-size: 14px;
  color: #b0b0b0;
  margin-bottom: 8px;
  display: flex;
  gap: 24px;
}
.goods-features2 {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 16px;
}
.goods-feature2 {
  border: 1px solid #e0e7ef;
  color: #b0b0b0;
  font-size: 14px;
  border-radius: 16px;
  padding: 4px 16px;
  background: #fff;
  font-weight: 500;
}
.goods-promo2 {
  margin-top: 8px;
  display: flex;
  align-items: center;
}
.promo-bg {
  background: linear-gradient(90deg, #FF7A45 0%, #FF3B30 100%);
  color: #fff;
  font-size: 16px;
  font-weight: bold;
  border-radius: 0 0 20px 20px;
  padding: 6px 32px 6px 24px;
  position: relative;
  display: inline-flex;
  align-items: center;
}
.promo-fire {
  position: absolute;
  right: 0;
  bottom: 0;
}
.goods-hot-tag {
  position: absolute;
  left: 16px;
  top: 16px;
  background: #FF7A45;
  color: #fff;
  font-size: 15px;
  font-weight: 500;
  border-radius: 10px;
  padding: 4px 14px;
  z-index: 2;
}
.special-image {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 120px;
}
.special-img {
  width: 115px;
  height: 113px;
  object-fit: contain;
  border-radius: 12px;
}
.special-features {
  justify-content: center;
  gap: 16px;
  margin-bottom: 16px;
}
.special-promo {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 8px;
}
.cut-img {
  height: 40px;
  width: auto;
  display: block;
}
.goods-default-layout {
  display: flex;
  flex-direction: column;
}
.goods-hover-layout {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(135deg, #B8E6E1 0%, #F0F4F8 100%);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 20px;
  box-sizing: border-box;
  opacity: 0;
  transition: opacity 0.3s ease;
  border-radius: 20px;
}
.first-card:hover .goods-hover-layout {
  opacity: 1;
}
.hover-header {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 12px;
}
.hover-app-icon {
  width: 80px;
  height: 80px;
  background: #000;
  border-radius: 16px;
  display: flex;
  justify-content: center;
  align-items: center;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}
.hover-icon-img {
  width: 60px;
  height: 60px;
  object-fit: contain;
}
.hover-app-info {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 8px;
}
.hover-app-name {
  font-size: 18px;
  font-weight: 400;
  color: #000;
  margin-bottom: 6px;
}
.hover-app-meta {
  display: flex;
  align-items: center;
  gap: 6px;
}
.hover-user-avatars {
  display: flex;
  gap: -2px;
  margin-right: 4px;
}
.hover-avatar {
  width: 20px;
  height: 20px;
  object-fit: cover;
  border-radius: 50%;
  border: 1px solid #fff;
}
.hover-purchased-text {
  font-size: 12px;
  color: #666;
  margin-right: 4px;
}
.hover-verified-icon {
  width: 16px;
  height: 16px;
  background: #235CDC;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
}
.hover-price-section {
  display: flex;
  align-items: baseline;
  margin-bottom: 6px;
  gap: 2px;
}
.hover-price-label {
  font-size: 14px;
  color: #FF3B30;
  font-weight: bold;
}
.hover-price-number {
  font-size: 20px;
  color: #FF3B30;
  font-weight: bold;
}
.hover-price-unit {
  font-size: 12px;
  color: #999;
}
.hover-stats {
  display: flex;
  gap: 20px;
  margin-bottom: 12px;
}
.hover-sales, .hover-rating {
  font-size: 12px;
  color: #666;
}
.hover-features {
  display: grid;
  grid-template-columns: 1fr 1fr;
  grid-template-rows: 1fr 1fr;
  gap: 8px 6px;
  justify-items: center;
  align-items: center;
  width: 100%;
  max-width: 200px;
  margin-bottom: 16px;
}
.hover-feature-tag {
  font-size: 12px;
  color: #666;
  padding: 4px 12px;
  background: #E8E8E8;
  border-radius: 16px;
  font-weight: 400;
  border: 1px solid #DDD;
}
.hover-buy-section {
  display: flex;
  justify-content: center;
  width: 100%;
}
.hover-buy-btn {
  width: 90%;
  padding: 12px 0;
  background: #235CDC;
  color: #fff;
  font-size: 16px;
  font-weight: 600;
  border: none;
  border-radius: 24px;
  cursor: pointer;
  transition: background 0.2s;
}
.hover-buy-btn:hover {
  background: #1e4bb8;
}
/* 确保只有第一个商品有悬停效果 */
.goods-card:not(.first-card) .goods-hover-layout {
  display: none;
}
</style> 