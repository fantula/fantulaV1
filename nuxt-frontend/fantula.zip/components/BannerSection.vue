<template>
  <section class="banner-section">
    <div class="banner-inner">
      <div class="banner-slider">
        <div v-for="banner in banners" :key="banner.id" class="banner-item">
          <img :src="banner.image" :alt="banner.title" class="banner-image" />
        </div>
      </div>
    </div>
  </section>
</template>

<script setup lang="ts">
import type { Banner } from '@/types/api'
const props = defineProps<{ banners: Banner[] }>()
</script>

<style scoped>
.banner-section {
  width: 100vw;
  min-width: 1180px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  margin-top: 104px;
  margin-bottom: 40px;
}
.banner-inner {
  width: 1181px;
  height: 404px;
  background: #fff;
  border-radius: 20px;
  box-shadow: 0px 8px 32px 0px rgba(0,0,0,0.08);
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
}
.banner-slider {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}
.banner-item {
  width: 100%;
  height: 100%;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}
.banner-image {
  width: 100%;
  height: 100%;
  object-fit: cover;
  border-radius: 20px;
}
.banner-content {
  position: absolute;
  left: 50%;
  top: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
  color: #fff;
  z-index: 2;
}
.banner-title {
  font-size: 2.5rem;
  font-weight: bold;
  margin-bottom: 1rem;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}
.banner-btn {
  display: inline-block;
  padding: 12px 30px;
  background: #ff6b6b;
  color: white;
  text-decoration: none;
  border-radius: 25px;
  font-weight: bold;
  transition: all 0.3s ease;
}
.banner-btn:hover {
  background: #ff5252;
  transform: translateY(-2px);
}
</style> 